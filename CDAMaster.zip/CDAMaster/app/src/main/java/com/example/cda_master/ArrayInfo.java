package com.example.cda_master;

import java.nio.DoubleBuffer;

public class ArrayInfo {
    String[] eiuCourseBreakdownCS = new String[]{"CIT 4770- Database and data management", "CIT 4823- Big data and cloud computing"
            , "CIT 4843- Human computer interaction", "CIT 1001- Intro to computers and information technology", "CIT 1813- Intro to programming(C++)"
            , "CIT 2523- Data Communication technology", "CIT 2773- Database administration", "CIT 2803- Operating Systems for computer technology"
            , "CIT 2853- Cybersecurity intrusion detection and prevention", "CIT 4663- System administration and architecture", "CIT 4749- Capstone project in computer information technology"
            , "CIT 4760- System analysis, design, and development", "CIT 4813- Web development", "CSM 2670- Object oriented programming", "CSM 3870- Data structures"
            , "AET 4814- Digital media strategy", "EGT 1323- Computers for engineering technology", "EFT 2324- Electricity and electronic controls"
            , "AET 3414- Engineering technology project management", " MIS 4700- Advanced Networking OR CIT 3153- Data communication technology"
            , "MIS 4850- Systems security", "OPD 4835- Supervision in organizations"};

    String[] eiuCourseBreakdownBM = new String[]{"BUS 1000- Introductory Business Seminar", "BUS 1950- Computer concepts and applications for business"
            , "BUS 2102- Financial accounting", "BUS 2102- Managerial accounting", "BUS 2750- Legal and social environment of business", "BUS 2810- Business Statistics"
            , "BUS 3010- Management and organizational behavior", "BUS 3200- International business", "BUS 3470- Principles of marketing", "BUS 3500- Mgmt information systems"
            , "BUS 3710- Business financial mgmt", "BUS 3950- Operations mgmt", "BUS 4360- Strategy and policy", "MGT 3450- Human resource management"
            , "MGT 3830- Managerial Communications", "MGT 4310- Organizational behavior", "MGT 4600- International business policy and operation"
            , "MGT 4650- Management seminar", "MAT2120G- Finite Mathematics", "ECN 2801G- Principles of macroeconomics", "ECN 2802G- Principles of microeconomics"};

    String[] illinoisCourseBreakdownCS = new String[]{"CS 125- Intro to computer science", "CS 126- Software design studio", "CS 173- Discrete Structures"
            , "CS 225- Data Structures", "CS 233- Computer Architecture", "CS 241- System programming", "CS 361- Probability and statistics for computer science"
            , "CS 357- Numerical methods 1", "CS 374- Intro to algorithms and models of computation", "CS 421- Programming languages and compilers"
            , "CS 100- Freshman Orientation", "CS 210- Ethical and professional issues", "ENG 100- Engineering orientation"};

    String[] illinoisCourseBreakdownBM = new String[]{"ACCY 201- Accounting and Accountancy 1", "ACCY 202- Accounting and Accountancy 2"
            , "BUS 101- Progessional responsibility and business", "BUS 201- Business Dynamics", "BUS 301- Business in action", "BUS 401- Business in a global perspective"
            , "BADM 210- Business Analytics 1", "BADM 211- Business Analytics 2", "BADM 275- Fundamentals of operations management", "BADM 300- The legal environment of business"
            , "BADM 310- Mgmt and organizational beh", "BADM 320- Principles of marketing", "BADM 449- Business policy and strategy", "CMN 101- Public speaking"
            , "CS 105- Intro computing: Non-tech", "ECON 102- Microeconomics principles", "ECON 103- Macroeconomics principles", "FIN 221- Corporate finance"
            , "MATH 234- Calculus for business 1"};

    String[] northwesternCourseBreakdownCS = new String[]{"COMP_SCI 212-0- Mathematical foundations of Computer Science", "MATH 220-1- Single variable differential calculus"
            ,"MATH 220-2- Single variable integral calculus", "MATH 228-1- Multivariable differential calculus for engineering", "GEN_ENG 205-1- Engineering analysis 1"
            , "GEN_ENG 205-2- Engineering analysis 2", "GEN_ENG 205-3- Engineering analysis 3", "COMP_SCI 111-0- Fundamentals of computer programming", "COMP_SCI 211-0- Fundamentals of computer programming 2"
            , "IEMS 201-0- Introduction to statistics", "COMP_SCI 101-0- Computer Science: concepts, philosophy, and connections", "COMP_SCI 213-0- Introduction to Computer Systems"
            , "COMP_SCI 214-0- Data structures and algorithms"};

    String[] northwesternCourseBreakdownBM = new String[]{"Accounting for decision making", "Business Analytics", "Leadership in organizations", "Finance 1", "Finance 2"
            , "Management Communications", "Operatings Management", "Marketing Management", "Business Strategy", "Global initiatives in management", "Marketing Research"
            , "Analytical Decision Modeling", "Negotiations", "Managerial Accounting"};

    String[] siuCourseBreakdownCS = new String[]{"CS 202- Introduction to computer science", "CS 215- Discrete Mathematics", "CS 220- Programming with Data Structures"
            , "CS 221- Introduction to internet and mobile computing", "CS 306- Linux/UNIX programming", "CS 330- Introduction to the design and analysis of algorithms"
            , "CS 335- Operating Systems", "CS 311- The theory and implementation of programming languages", "CS 320- Computer organization and architecture"};

    String[] siuCourseBreakdownBM = new String[]{"MGMT 341- Organization behavior", "MGMT 380- Managing information systems", "MGMT 483- Advanceced Prod-Operations mgmt"
            , "--Select 4 --", "MGMT 352- Management science", "MGMT 385- Human resource Management", "MGMT 420- Project Management", "MGMT431- Organization design and structures",
            "MGMT 446- Leadership and Mgrl behavior", "MGMT 447- Training and development", "MGMT 474- Mgmts responsibility society", "MGMT 485- Organizational change and development"
            , "MGMT 495- Internship in management"};

    String[] harvardCourseBreakdownCS = new String[]{"CS 121- Introduction to theoretical computer science", " CS 124- Data structures and algorithms"
            , "CS 20- Discrete Mathematics for computer science", "AM 106- Applied Algebra", "AM 107- Theory of computation", "-- Select 2 --"
            , "CS 50- Introduction to Computer Science", "CS 51- Abstraction and Design in computation", "CS 61- Systems programming and machine organization"};

    String[] harvardCourseBreakdownBM = new String[]{"Finance 1", "Finance 2", "Financial reporting and control (FRC)", "Leadership and organizational behavior (LEAD)"
            , "Marketing", "Technology and Operations management (TOM)", "Business, Government, and the international economy (BGIE)", "The entrepreneurial manager (TEM)"
            , "Leadership and Corporate Accountability (LCA)", "FIELD global immersion"};

    String[] isuCourseBreakdownCS = new String[]{"COM 223- Small group processes", "ENG 249- Technical and professional writing"
            , "IT 168- Structured problem solving using the computer", "IT 179- Introduction to data structures", "IT 180- C++ Programming", "IT 214- Social, legal, and ethical issues in information technology"
            , "IT 225- Computer Organization", "IT 261- Systems development 1", "IT 279- Algorithms and Data Structures", "IT 326- Principles of software engineering", "IT 327- Concepts of programming languages"
            , "IT 378- Database processing", "IT 383- Principles of operating systems", "IT 386- Intro to networking and parallel and distributed computing"
            , "IT 398- Professional practice in information technology", "MAT 145- Calculus 1", "MAT 146- Calculus 2", "MAT 260- Discrete Mathematics"};

    String[] isuCourseRequirementsMinorMath = new String[]{"MAT 145 - Calculus I", "MAT 146 - Calculus II", "Select 4---", "MAT 147 - Calculus III",
            "MAT 175 - Elementary Linear Algebra", "MAT 236 - Elementary Abstract Algebra", "MAT 247 - Elementary Real Analysis", "MAT 260 - Discrete Mathematics"
            , "MAT 268 - Introduction To Undergraduate Research In Mathematics", "MAT 330 - Number Theory", "MAT 336 - Advanced Abstract Algebra"
            , "MAT 337 - Advanced Linear Algebra", "MAT 340 - Differential Equations I", "MAT 341 - Differential Equations II", "MAT 345 - Advanced Calculus"
            , "MAT 347 - Advanced Real Analysis", "MAT 350 - Applied Probability Models", "MAT 351 - Statistics And Data Analysis"
            , "MAT 361 - Topics In Discrete Mathematics", "MAT 362 - Linear Optimization", "MAT 363 - Graph Theory", "End Select 4---"};

    String[] isuCourseRequirementsMinorPsych = new String[]{"Select 1---", "PSY 110 - Fundamentals Of Psychology", "PSY 111 - Introduction To Psychology", "End Select 1---"
            , "PSY 231 - Research Methods In Psychology", "PSY 233 - Psychology Of Personality", "Select 1---", "PSY 138 - Reasoning In Psychology Using Statistics"
            , "ECO 138 - Economic Reasoning Using Statistics", "POL 138 - Quantitative Reasoning In Political Science", "MQM 100 - Statistical Reasoning"
            , "MAT 150 - Fundamentals Of Statistical Reasoning", "SOC 275 - Social Statistics", "End Select 1---"};

    String[] eiuCourseRequirementsMinorMath = new String[]{"MAT 1441G - Calculus and Analytic Geometry I", "MAT 2442 - Calculus and Analytic Geometry II"
            , "MAT 2443 - Calculus and Analytic Geometry III", "Electives in mathematics selected in consultation with a math advisor"};

    String[] eiuCourseRequirementsMinorPsych = new String[]{"PSY 1879G - Introductory Psychology", "Select 2---"
            , "PSY 3590 - Theories of Personality", "PSY 3780 - Abnormal Psychology", "PSY 3870 - Social Psychology"
            , "PSY 3310 - Biological Psychology", "PSY 3450 - Neuropsychology", "PSY 3680 - Sensation and Perception"
            , "PSY 3820 - Cognitive Neuroscience", "PSY 3620 - Psychology of Learning", "PSY 3710 - Human Memory"
            , "PSY 3830 - Cognitive Psychology", "PSY 3515 - Child Psychology", "PSY 3521 - Psychology of Adolescence and Young Adulthood"
            , "PSY 3525 - Psychology of Maturity and Old Age", "Electives in Psychology selected to meet the particular educational goals of individual students in consultation with a Psychology advisor"};

    String[] nwuCourseRequirementsMinorMath = new String[]{"Select 1 Group---", "Begin Group I"
            , "MATH 220-0 Differential Calculus of One-Variable Functions", "MATH 224-0 Differential Calculus of One-Variable Functions Integral Calculus of One-Variable Functions"
            , "End Group I", "Begin Group II", "MATH 212-0 Single Variable Calculus I", "MATH 213-0 Single Variable Calculus II"
            , "MATH 214-0 Single Variable Calculus III", "End Group II", "End Select 1 Group---"};

    String[] nwuCourseRequirementsMinorPsych = new String[]{"PSYCH 110-0 Introduction to Psychology"
            , "PSYCH 201-0 Statistical Methods in Psychology (or approved substitute)", "PSYCH 205-0 Research Methods in Psychology"
            , "Select 1---", "PSYCH 204-0 Social Psychology", "PSYCH 215-0 Psychology of Personality", "PSYCH 303-0 Psychopathology"
            , "PSYCH 315-0 Special Topics in Social/Clinical/Personality", "PSYCH 326-0 Social and Personality Development"
            , "PSYCH 357-0 Advanced Seminar in Personality, Clinical, or Social Psychology", "PSYCH 384-0 Close Relationships"
            , "End Select 1---", "Select 1---", "PSYCH 212-0 Introduction to Neuroscience", "PSYCH 228-0 Cognitive Psychology"
            , "PSYCH 312-1 Selected Topics in Neuroscience and Psychophysiology", "PSYCH 316-0 Special Topics in Cognition/Neuroscience"
            , "PSYCH 324-0 Perception", "PSYCH 333-0 Psychology of Thinking", "PSYCH 336-0 Consciousness", "PSYCH 346-0 Psychology of Instructional Design and Technology"
            , "PSYCH 358-0 Advanced Seminar in Cognition or Neuroscience", "PSYCH 361-0 Brain Damage and the Mind"
            , "PSYCH 362-0 Cogntive Development", "PSYCH 363-0 Images of Cognition", "PSYCH 365-0 Brain and Cognition"
            , "COG_SCI 210-0 Language and the Brain", "COG_SCI 211-0 Learning, Representation & Reasoning", "End Select 1---"
            , "At least 1 200-level psychology department course", "At least 2 300-level psychology department courses"};

    String[] huCourseRequirementsMinorMath = new String[]{"No minor available"};

    String[] huCourseRequirementsMinorPsych = new String[]{"No minor available"};

    String[] uiCourseRequirementsMinorMath = new String[]{"MATH 241 - Calculus III", "Select 5---"
            , "MATH 347 - Fundamental Mathematics", "ASRM 406 - Linear Algebra with Financial Applications (formerly MATH 410)"
            , "MATH 415 - Applied Linear Algebra", "MATH 416 - Abstract Linear Algebra", "MATH 417 - Intro to Abstract Algebra"
            , "MATH 418 - Intro to Abstract Algebra II", "MATH 427 - Honors Abstract Algebra", "MATH 453 - Elementary Theory of Numbers"
            , "MATH 412 - Graph Theory", "MATH 413 - Intro to Combinatorics", "MATH 414 - Mathematical Logic",
            "MATH 482 - Linear Programming", "MATH 284 - Intro Differential Systems", "MATH 285 - Intro Differential Equations"
            , "MATH 286 - Intro to Differential Eq Plus", "MATH 424 - Honors Real Analysis", "MATH 425 - Honors Advanced Analysis"
            , "MATH 441 - Differential Equations", "MATH 442 - Intro Partial Diff Equations", "MATH 444 - Elementary Real Analysis"
            , "MATH 446 - Applied Complex Variables", "MATH 447 - Real Variables", "MATH 448 - Complex Variables",
            "CS 450 - Numerical Analysis", "MATH 484 - Nonlinear Programming", "MATH 487 - Advanced Engineering Math",
            "MATH 489 - Dynamics & Differential Eqns", "MATH 402 - Non Euclidean Geometry", "MATH 403 - Euclidean Geometry",
            "MATH 423 - Differential Geometry", "MATH 428 - Honors Topics in Mathematics", "MATH 432 - Set Theory and Topology",
            "MATH 481 - Vector and Tensor Analysis", "MATH 461 - Probability Theory", "STAT 400 - Statistics and Probability I",
            "STAT 410 - Statistics and Probability II", "STAT 420 - Methods of Applied Statistics", "End Select 5---"};


    String[] uiCourseRequirementsMinorPsych = new String[]{"PSYC 100 - Intro Psych", "PSYC 235 - Intro to Statistics (or equivalent)"
            , "Select 1---", "PSYC 204 - Intro to Brain and Cognition", "PSYC 210 - Behavioral Neuroscience", "PSYC 220 - Images of Mind"
            , "PSYC 224 - Cognitive Psych", "PSYC 230 - Perception & Sensory Processes", "PSYC 248 - Learning and Memory",
            "End Select 1---", "Select 1---", "PSYC 201 - Intro to Social Psych", "PSYC 216 - Child Psych"
            , "PSYC 238 - Psychopathology and Problems in Living", "PSYC 239 - Community Psych", "PSYC 245 - Industrial Org Psych"
            , "PSYC 250 - Psych of Personality", "End Select 1---", "Select two 300- or 400- level Psychology courses"};

    String[] siuCourseRequirementsMinorMath = new String[]{"No minor available"};

    String[] siuCourseRequirementsMinorPsych = new String[]{"Select 1 Group---", "Select 5---", "Begin Group I", "PSYC 233", "PSYC 237"
            , "PSYC 301", "PSYC 303", "PSYC 304", "PSYC 305", "PSYC 306", "PSYC 307", "PSYC 331", "PSYC 333", "PSYC 334", "PSYC 431"
            , "PSYC 432", "PSYC 440", "PSYC 451", "PSYC 461", "PSYC 464", "PSYC 470", "CI 403", "PSYC 408", "End Group I"
            , "Begin Group II", "PSYC 302", "PSYC 308", "PSYC 309", "PSYC 310", "PSYC 312", "PSYC 345", "PSYC 402", "PSYC 407"
            , "PSYC 409", "PSYC 415", "PSYC 416", "PSYC 419", "PSYC 445", "PSYC 471", "End Group II", "Begin Group III", "PSYC 223"
            , "PSYC 314", "PSYC 322", "PSYC 323", "PSYC 340", "PSYC 411", "PSYC 413", "PSYC 420", "PSYC 421", "PSYC 425", "PSYC 441"
            , "PSYC 465", "End Group III", "Begin Group IV", "PSYC 222", "PSYC 389", "PSYC 391", "PSYC 392", "PSYC 393", "PSYC 394"
            , "PSYC 489", "PSYC 499A&B", "Math 282", "EPSY 402", "End Group IV", "End Select 5---"};

    String[] isuCourseBreakdownBM = new String[]{"ACC 131- Financial Accounting" , "ACC 132- Managerial Accounting", "ACC 270- Information Systems in Organizations"
            , "BUS 100- Enterprise", "BUS 285- Business fundamentals exam", "ECO 101- Principles of Microeconomics", "ECO 102- Principles of Macroeconomics"
            , "FIL 185- Legal, ethical, and social environment of business", "FIL 240- Business Finance", "MKT 230- Introduction to marketing management",
            "MQM 100- Statistical reasoning", "MQM 220- Business organization and management", "MQM 227- Operations Management", "MQM 385- Organizational Strategy"
            , "MQM 221- Organizational behavior and administration", "MQM 335- Operations analytics-Quality management", "ACC 230- Cost and management accounting"
            , "ACC 255- Electronic business management", "MKT 232- Marketing Research"};

    double[] ISU  = {15319, 9850, 21039, 68.8};
    double[] SIU  = {9638, 10622, 14554, 50.0};
    double[] UIUC  = {21956, 12252, 44087, 88.0};
    double[] NU  = {56232, 17019, 21000, 94.0};
    double[] EIU  = {9241.2, 9882, 7806, 57.0};
    double[] HU  = {49653, 11364, 36012, 98.0};


}
