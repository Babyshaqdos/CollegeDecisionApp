package com.example.cda_master;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

public class courseActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coursebreakdown3);
        View view = findViewById(R.id.courselayout3);
        view.setOnTouchListener(new DetectSwiping(courseActivity3.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent = new Intent(courseActivity3.this, courseActivity.class);
                startActivity(topIntent);
            }
            public void onSwipeRight(){
                Intent intent = new Intent(courseActivity3.this, costActivity3.class);
                startActivity(intent);

            }
            public void onSwipeLeft(){
                //Do Nothing
            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent = new Intent(courseActivity3.this, courseActivity2.class);
                startActivity(downIntent);
            }
        });
    }
}