package com.example.cda_master;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

public class costActivity3 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.costbreakdown3);

        //Create and set listener on layout view that handles the swiping between screens
        View view = findViewById(R.id.costlayout3);
        view.setOnTouchListener(new DetectSwiping(costActivity3.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent3 = new Intent(costActivity3.this, costActivity.class);
                startActivity(topIntent3);
            }
            public void onSwipeRight(){
                //Do Nothing
            }
            public void onSwipeLeft(){
                //Swap to course breakdown
                Intent intent = new Intent(costActivity3.this, courseActivity3.class);
                startActivity(intent);
            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent3 = new Intent(costActivity3.this, costActivity2.class);
                startActivity(downIntent3);
            }
        });
    }
    //Function to open a new course activity class
    public void openCourseActivity(){
        Intent intent = new Intent(this, courseActivity.class);
        startActivity(intent);
    }
}