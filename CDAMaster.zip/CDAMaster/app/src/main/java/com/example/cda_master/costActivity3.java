package com.example.cda_master;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

public class costActivity3 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.costbreakdown3);

        //Create and set listener on layout view that handles the swiping between screens
        View view = findViewById(R.id.costlayout3);
        populateLayout();
        view.setOnTouchListener(new DetectSwiping(costActivity3.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent3 = new Intent(costActivity3.this, costActivity.class);
                topIntent3.putExtras(getIntent().getExtras());
                startActivity(topIntent3);
            }
            public void onSwipeRight(){
                //Do Nothing
            }
            public void onSwipeLeft(){
                //Swap to course breakdown
                Intent intent = new Intent(costActivity3.this, courseActivity3.class);
                intent.putExtras(getIntent().getExtras());
                startActivity(intent);
            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent3 = new Intent(costActivity3.this, costActivity2.class);
                downIntent3.putExtras(getIntent().getExtras());
                startActivity(downIntent3);
            }
        });
    }

    public void populateLayout(){
        TextView schoolName1 = (TextView) findViewById(R.id.schoolName3);
        TextView inStateTuition = (TextView) findViewById((R.id.inStateTuitionCost3));
        TextView onCampusLiving = (TextView) findViewById(R.id.onCampusLivingCost3);
        TextView studentSize = (TextView) findViewById(R.id.studentSize3);
        TextView gradPercent = (TextView) findViewById(R.id.gradPercent3);
        Intent intent = getIntent();
        String schoolname = intent.getStringExtra("School3");
        schoolName1.setText(schoolname);
        switch(schoolname){
            case "Southern Illinois University":
                double[] schoolInfo = intent.getDoubleArrayExtra("SIUArray");
                String tuition = "Cost of tuition per year: ";
                tuition += Double.toString(schoolInfo[0]);
                tuition += "$";
                String costLiving = "Cost of living(estimated on campus): ";
                costLiving += Double.toString(schoolInfo[1]);
                costLiving += "$";
                String numStudents = "Last reported number of students: ";
                numStudents += Double.toString(schoolInfo[2]);
                String gradRate = "Graduation Rate: ";
                gradRate += Double.toString(schoolInfo[3]);
                gradRate += "%";
                inStateTuition.setText(tuition);
                onCampusLiving.setText(costLiving);
                studentSize.setText(numStudents);
                gradPercent.setText(gradRate);
                break;
            case "Eastern Illinois University":
                double[] schoolInfo2 = intent.getDoubleArrayExtra("EIUArray");
                String tuition2 = "Cost of tuition per year: ";
                tuition2 += Double.toString(schoolInfo2[0]);
                tuition2 += "$";
                String costLiving2 = "Cost of living(estimated on campus): ";
                costLiving2 += Double.toString(schoolInfo2[1]);
                costLiving2 += "$";
                String numStudents2 = "Last reported number of students: ";
                numStudents2 += Double.toString(schoolInfo2[2]);
                String gradRate2 = "Graduation Rate: ";
                gradRate2 += Double.toString(schoolInfo2[3]);
                gradRate2 += "%";
                inStateTuition.setText(tuition2);
                onCampusLiving.setText(costLiving2);
                studentSize.setText(numStudents2);
                gradPercent.setText(gradRate2);
                break;
            case "Northwestern":
                double[] schoolInfo3 = intent.getDoubleArrayExtra("NWUArray");
                String tuition3 = "Cost of tuition per year: ";
                tuition3 += Double.toString(schoolInfo3[0]);
                tuition3 += "$";
                String costLiving3 = "Cost of living(estimated on campus): ";
                costLiving3 += Double.toString(schoolInfo3[1]);
                costLiving3 += "$";
                String numStudents3 ="Last reported number of students: ";
                numStudents3 += Double.toString(schoolInfo3[2]);
                String gradRate3 = "Graduation Rate: ";
                gradRate3 += Double.toString(schoolInfo3[3]);
                gradRate3 += "%";
                inStateTuition.setText(tuition3);
                onCampusLiving.setText(costLiving3);
                studentSize.setText(numStudents3);
                gradPercent.setText(gradRate3);
                break;
            case "Harvard":
                double[] schoolInfo4 = intent.getDoubleArrayExtra("HUArray");
                String tuition4 = "Cost of tuition per year:";
                tuition4 += Double.toString(schoolInfo4[0]);
                tuition4 += "$";
                String costLiving4 = "Cost of living(estimated on campus): ";
                costLiving4+=Double.toString(schoolInfo4[1]);
                costLiving4 += "$";
                String numStudents4 = "Last reported number of students: ";
                numStudents4 += Double.toString(schoolInfo4[2]);
                String gradRate4 = "Graduation Rate: ";
                gradRate4 += Double.toString(schoolInfo4[3]);
                gradRate4 += "%";
                inStateTuition.setText(tuition4);
                onCampusLiving.setText(costLiving4);
                studentSize.setText(numStudents4);
                gradPercent.setText(gradRate4);
                break;
            case "University of Illinois":
                double[] schoolInfo5 = intent.getDoubleArrayExtra("UIUCArray");
                String tuition5 = "Cost of tuition per year: ";
                tuition5 += Double.toString(schoolInfo5[0]);
                tuition5 += "$";
                String costLiving5 = "Cost of living(estimated on campus): ";
                costLiving5 += Double.toString(schoolInfo5[1]);
                costLiving5 += "$";
                String numStudents5 = "Last reported number of students: ";
                numStudents5 += Double.toString(schoolInfo5[2]);
                String gradRate5 = "Graduation Rate: ";
                gradRate5 += Double.toString(schoolInfo5[3]);
                gradRate5 += "%";
                inStateTuition.setText(tuition5);
                onCampusLiving.setText(costLiving5);
                studentSize.setText(numStudents5);
                gradPercent.setText(gradRate5);
                break;
            case "Illinois State University":
                double[] schoolInfo6 = intent.getDoubleArrayExtra("ISUArray");
                String tuition6 = "Cost of tuition per year: ";
                tuition6 += Double.toString(schoolInfo6[0]);
                tuition6 += "$";
                String costLiving6 = "Cost of living(estimated on campus): ";
                costLiving6 += Double.toString(schoolInfo6[1]);
                costLiving6 += "$";
                String numStudents6 = "Last reported number of students: ";
                numStudents6 += Double.toString(schoolInfo6[2]);
                String gradRate6 = "Graduation Rate: ";
                gradRate6 += Double.toString(schoolInfo6[3]);
                gradRate6 += "%";
                inStateTuition.setText(tuition6);
                onCampusLiving.setText(costLiving6);
                studentSize.setText(numStudents6);
                gradPercent.setText(gradRate6);
                break;
            default:
                break;
        }
    }
}
