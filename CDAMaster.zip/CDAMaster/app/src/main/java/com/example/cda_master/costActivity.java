package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class costActivity extends AppCompatActivity {
    float x1, x2, y1, y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.costbreakdown);
        View view = findViewById(R.id.costlayout1);
        populateLayout();
        view.setOnTouchListener(new DetectSwiping(costActivity.this){
           public void onSwipeTop(){
               //Swap to new cost activity
               Intent topintent = new Intent(costActivity.this, costActivity2.class);
               topintent.putExtras(getIntent().getExtras());
               startActivity(topintent);
           }
           public void onSwipeRight(){
              //Do nothing
           }
           public void onSwipeLeft(){
               //Swap to course breakdown
               Intent intent = new Intent(costActivity.this, courseActivity.class);
               intent.putExtras(getIntent().getExtras());
               startActivity(intent);
           }
           public void onSwipeBottom(){
               //Swap to new cost activity
               Intent downIntent = new Intent(costActivity.this, costActivity3.class);
               downIntent.putExtras(getIntent().getExtras());
               startActivity(downIntent);
           }
        });
    }


    public void populateLayout(){
        TextView schoolName1 = (TextView) findViewById(R.id.schoolName);
        TextView inStateTuition = (TextView) findViewById((R.id.inStateTuitionCost));
        TextView onCampusLiving = (TextView) findViewById(R.id.onCampusLivingCost);
        TextView studentSize = (TextView) findViewById(R.id.studentSize);
        TextView gradPercent = (TextView) findViewById(R.id.gradPercent);
        Intent intent = getIntent();
        String schoolname = intent.getStringExtra("School1");
        schoolName1.setText(schoolname);
        switch(schoolname){
            case "Southern Illinois University":
                double[] schoolInfo = intent.getDoubleArrayExtra("SIUArray");
                String tuition = "Cost of tuition per year: ";
                        tuition += Double.toString(schoolInfo[0]);
                        tuition += "$";
                String costLiving = "Cost of living(estimated on campus): ";
                        costLiving += Double.toString(schoolInfo[1]);
                        costLiving += "$";
                String numStudents = "Last reported number of students: ";
                        numStudents += Double.toString(schoolInfo[2]);
                String gradRate = "Graduation Rate: ";
                        gradRate += Double.toString(schoolInfo[3]);
                gradRate += "%";
                inStateTuition.setText(tuition);
                onCampusLiving.setText(costLiving);
                studentSize.setText(numStudents);
                gradPercent.setText(gradRate);
                break;
            case "Eastern Illinois University":
                double[] schoolInfo2 = intent.getDoubleArrayExtra("EIUArray");
                String tuition2 = "Cost of tuition per year: ";
                tuition2 += Double.toString(schoolInfo2[0]);
                tuition2 += "$";
                String costLiving2 = "Cost of living(estimated on campus): ";
                costLiving2 += Double.toString(schoolInfo2[1]);
                costLiving2 += "$";
                String numStudents2 = "Last reported number of students: ";
                numStudents2 += Double.toString(schoolInfo2[2]);
                String gradRate2 = "Graduation Rate: ";
                gradRate2 += Double.toString(schoolInfo2[3]);
                gradRate2 += "%";
                inStateTuition.setText(tuition2);
                onCampusLiving.setText(costLiving2);
                studentSize.setText(numStudents2);
                gradPercent.setText(gradRate2);
                break;
            case "Northwestern":
                double[] schoolInfo3 = intent.getDoubleArrayExtra("NWUArray");
                String tuition3 = "Cost of tuition per year: ";
                tuition3 += Double.toString(schoolInfo3[0]);
                tuition3 += "$";
                String costLiving3 = "Cost of living(estimated on campus): ";
                costLiving3 += Double.toString(schoolInfo3[1]);
                costLiving3 += "$";
                String numStudents3 ="Last reported number of students: ";
                numStudents3 += Double.toString(schoolInfo3[2]);
                String gradRate3 = "Graduation Rate: ";
                gradRate3 += Double.toString(schoolInfo3[3]);
                gradRate3 += "%";
                inStateTuition.setText(tuition3);
                onCampusLiving.setText(costLiving3);
                studentSize.setText(numStudents3);
                gradPercent.setText(gradRate3);
                break;
            case "Harvard":
                double[] schoolInfo4 = intent.getDoubleArrayExtra("HUArray");
                String tuition4 = "Cost of tuition per year:";
                tuition4 += Double.toString(schoolInfo4[0]);
                tuition4 += "$";
                String costLiving4 = "Cost of living(estimated on campus): ";
                costLiving4+=Double.toString(schoolInfo4[1]);
                costLiving4 += "$";
                String numStudents4 = "Last reported number of students: ";
                numStudents4 += Double.toString(schoolInfo4[2]);
                String gradRate4 = "Graduation Rate: ";
                gradRate4 += Double.toString(schoolInfo4[3]);
                gradRate4 += "%";
                inStateTuition.setText(tuition4);
                onCampusLiving.setText(costLiving4);
                studentSize.setText(numStudents4);
                gradPercent.setText(gradRate4);
                break;
            case "University of Illinois":
                double[] schoolInfo5 = intent.getDoubleArrayExtra("UIUCArray");
                String tuition5 = "Cost of tuition per year: ";
                tuition5 += Double.toString(schoolInfo5[0]);
                tuition5 += "$";
                String costLiving5 = "Cost of living(estimated on campus): ";
                costLiving5 += Double.toString(schoolInfo5[1]);
                costLiving5 += "$";
                String numStudents5 = "Last reported number of students: ";
                numStudents5 += Double.toString(schoolInfo5[2]);
                String gradRate5 = "Graduation Rate: ";
                gradRate5 += Double.toString(schoolInfo5[3]);
                gradRate5 += "%";
                inStateTuition.setText(tuition5);
                onCampusLiving.setText(costLiving5);
                studentSize.setText(numStudents5);
                gradPercent.setText(gradRate5);
                break;
            case "Illinois State University":
                double[] schoolInfo6 = intent.getDoubleArrayExtra("ISUArray");
                String tuition6 = "Cost of tuition per year: ";
                tuition6 += Double.toString(schoolInfo6[0]);
                tuition6 += "$";
                String costLiving6 = "Cost of living(estimated on campus): ";
                costLiving6 += Double.toString(schoolInfo6[1]);
                costLiving6 += "$";
                String numStudents6 = "Last reported number of students: ";
                numStudents6 += Double.toString(schoolInfo6[2]);
                String gradRate6 = "Graduation Rate: ";
                gradRate6 += Double.toString(schoolInfo6[3]);
                gradRate6 += "%";
                inStateTuition.setText(tuition6);
                onCampusLiving.setText(costLiving6);
                studentSize.setText(numStudents6);
                gradPercent.setText(gradRate6);
                break;
            default:
                break;
        }

    }


}