package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

public class costActivity extends AppCompatActivity {
    float x1, x2, y1, y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.costbreakdown);
        View view = findViewById(R.id.costlayout1);
        view.setOnTouchListener(new DetectSwiping(costActivity.this){
           public void onSwipeTop(){
               //Swap to new cost activity
               Intent topintent = new Intent(costActivity.this, costActivity2.class);
               startActivity(topintent);
           }
           public void onSwipeRight(){
              //Do nothing
           }
           public void onSwipeLeft(){
               //Swap to course breakdown
               Intent intent = new Intent(costActivity.this, courseActivity.class);
               startActivity(intent);
           }
           public void onSwipeBottom(){
               //Swap to new cost activity
               Intent downIntent = new Intent(costActivity.this, costActivity3.class);
               startActivity(downIntent);
           }
        });
    }
    /* Ignore this for now, I ended up implementing the swiping functionality a different way but am leaving this for documentation
    //Basic implementation, need to set it to change the intents to the correct activity based on action up or action down
    //Also need to implement swiping left or right
    public boolean onTouchEvent(MotionEvent touchEvent){
        switch(touchEvent.getAction()){
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                if(x1 < x2){

                }
                break;
        }
        return false;
    } */

    public void openCourseActivity(){
        Intent intent = new Intent(this, courseActivity.class);
        startActivity(intent);
    }

}