package com.example.cda_master;

import android.view.GestureDetector;
import android.view.MotionEvent;


///Ignore this class for now, this was an attempt to get the swipe functionality built in but I ended up
//Getting it to work it a different way. Leaving this in for future reference
public class DetectSwiping extends GestureDetector.SimpleOnGestureListener {

    private static int MIN_SWIPE_DISTANCE_X = 100;
    private static int MIN_SWIPE_DISTANCE_Y = 100;

    private static int MAX_SWIPE_DISTANCE_X = 1000;
    private static int MAX_SWIPE_DISTANCE_Y = 1000;

    //Activity that displays the message
    //Need to change this, maybe make it this.activity? but it should not be the main activity
    private MainActivity activity = null;

    public MainActivity getActivity(){
        return activity;
    }

    public void setActivity(MainActivity activity){
        this.activity=activity;
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY){
        float deltaX = e1.getX() - e2.getX();
        float deltaY = e1.getY() - e2.getY();

        float deltaXabs = Math.abs(deltaX);
        float deltaYabs = Math.abs(deltaY);

        if(deltaXabs >= MIN_SWIPE_DISTANCE_X && deltaXabs <= MAX_SWIPE_DISTANCE_X){
            if(deltaX > 0){

            }else{

            };
        };
        return false;
    };

}
