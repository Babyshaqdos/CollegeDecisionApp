package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class courseActivity extends AppCompatActivity {
    float x1, x2, y1, y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coursebreakdown);
        View view = findViewById(R.id.courselayout1);
        view.setOnTouchListener(new DetectSwiping(courseActivity.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent = new Intent(courseActivity.this, courseActivity2.class);
                startActivity(topIntent);
            }
            public void onSwipeRight(){
                Intent intent = new Intent(courseActivity.this, costActivity.class);
                startActivity(intent);

            }
            public void onSwipeLeft(){

            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent = new Intent(courseActivity.this, courseActivity3.class);
                startActivity(downIntent);
            }
        });
    }

    public void openCostActivity(){
        Intent intent = new Intent(this, costActivity.class);
        startActivity(intent);
    }
}