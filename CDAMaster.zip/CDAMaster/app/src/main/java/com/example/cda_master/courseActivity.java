package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class courseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coursebreakdown);
    }
}