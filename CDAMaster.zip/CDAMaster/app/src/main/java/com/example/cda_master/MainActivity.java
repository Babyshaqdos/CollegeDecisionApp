package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    //Get each school choice and place into string
    EditText num1;
    String school1;
    EditText num2;
    String school2;
    EditText num3;
    String school3;
    EditText majorholder;
    EditText minorholder;
    String major;
    String minor;
    String schoolurl1;
    String schoolurl2;
    String schoolurl3;
    int numChoices;

    String[] eiuCourseBreakdownCS = new String[]{"CIT 4770- Database and data management", "CIT 4823- Big data and cloud computing"
    , "CIT 4843- Human computer interaction", "CIT 1001- Intro to computers and information technology", "CIT 1813- Intro to programming(C++)"
    , "CIT 2523- Data Communication technology", "CIT 2773- Database administration", "CIT 2803- Operating Systems for computer technology"
    , "CIT 2853- Cybersecurity intrusion detection and prevention", "CIT 4663- System administration and architecture", "CIT 4749- Capstone project in computer information technology"
    , "CIT 4760- System analysis, design, and development", "CIT 4813- Web development", "CSM 2670- Object oriented programming", "CSM 3870- Data structures"
    , "AET 4814- Digital media strategy", "EGT 1323- Computers for engineering technology", "EFT 2324- Electricity and electronic controls"
    , "AET 3414- Engineering technology project management", " MIS 4700- Advanced Networking OR CIT 3153- Data communication technology"
    , "MIS 4850- Systems security", "OPD 4835- Supervision in organizations"};

    String[] eiuCourseBreakdownBM = new String[]{"BUS 1000- Introductory Business Seminar", "BUS 1950- Computer concepts and applications for business"
    , "BUS 2102- Financial accounting", "BUS 2102- Managerial accounting", "BUS 2750- Legal and social environment of business", "BUS 2810- Business Statistics"
    , "BUS 3010- Management and organizational behavior", "BUS 3200- International business", "BUS 3470- Principles of marketing", "BUS 3500- Mgmt information systems"
    , "BUS 3710- Business financial mgmt", "BUS 3950- Operations mgmt", "BUS 4360- Strategy and policy", "MGT 3450- Human resource management"
    , "MGT 3830- Managerial Communications", "MGT 4310- Organizational behavior", "MGT 4600- International business policy and operation"
    , "MGT 4650- Management seminar", "MAT2120G- Finite Mathematics", "ECN 2801G- Principles of macroeconomics", "ECN 2802G- Principles of microeconomics"};

    String[] illinoisCourseBreakdownCS = new String[]{"CS 125- Intro to computer science", "CS 126- Software design studio", "CS 173- Discrete Structures"
    , "CS 225- Data Structures", "CS 233- Computer Architecture", "CS 241- System programming", "CS 361- Probability and statistics for computer science"
    , "CS 357- Numerical methods 1", "CS 374- Intro to algorithms and models of computation", "CS 421- Programming languages and compilers"
    , "CS 100- Freshman Orientation", "CS 210- Ethical and professional issues", "ENG 100- Engineering orientation"};

    String[] illinoisCourseBreakdownBM = new String[]{"ACCY 201- Accounting and Accountancy 1", "ACCY 202- Accounting and Accountancy 2"
    , "BUS 101- Progessional responsibility and business", "BUS 201- Business Dynamics", "BUS 301- Business in action", "BUS 401- Business in a global perspective"
    , "BADM 210- Business Analytics 1", "BADM 211- Business Analytics 2", "BADM 275- Fundamentals of operations management", "BADM 300- The legal environment of business"
    , "BADM 310- Mgmt and organizational beh", "BADM 320- Principles of marketing", "BADM 449- Business policy and strategy", "CMN 101- Public speaking"
    , "CS 105- Intro computing: Non-tech", "ECON 102- Microeconomics principles", "ECON 103- Macroeconomics principles", "FIN 221- Corporate finance"
    , "MATH 234- Calculus for business 1"};

    String[] northwesternCourseBreakdownCS = new String[]{"COMP_SCI 212-0- Mathematical foundations of Computer Science", "MATH 220-1- Single variable differential calculus"
    ,"MATH 220-2- Single variable integral calculus", "MATH 228-1- Multivariable differential calculus for engineering", "GEN_ENG 205-1- Engineering analysis 1"
    , "GEN_ENG 205-2- Engineering analysis 2", "GEN_ENG 205-3- Engineering analysis 3", "COMP_SCI 111-0- Fundamentals of computer programming", "COMP_SCI 211-0- Fundamentals of computer programming 2"
    , "IEMS 201-0- Introduction to statistics", "COMP_SCI 101-0- Computer Science: concepts, philosophy, and connections", "COMP_SCI 213-0- Introduction to Computer Systems"
    , "COMP_SCI 214-0- Data structures and algorithms"};

    String[] northwesternCourseBreakdownBM = new String[]{"Accounting for decision making", "Business Analytics", "Leadership in organizations", "Finance 1", "Finance 2"
    , "Management Communications", "Operatings Management", "Marketing Management", "Business Strategy", "Global initiatives in management", "Marketing Research"
    , "Analytical Decision Modeling", "Negotiations", "Managerial Accounting"};

    String[] siuCourseBreakdownCS = new String[]{"CS 202- Introduction to computer science", "CS 215- Discrete Mathematics", "CS 220- Programming with Data Structures"
    , "CS 221- Introduction to internet and mobile computing", "CS 306- Linux/UNIX programming", "CS 330- Introduction to the design and analysis of algorithms"
    , "CS 335- Operating Systems", "CS 311- The theory and implementation of programming languages", "CS 320- Computer organization and architecture"};

    String[] siuCourseBreakdownBM = new String[]{"MGMT 341- Organization behavior", "MGMT 380- Managing information systems", "MGMT 483- Advanceced Prod-Operations mgmt"
    , "--Select 4 --", "MGMT 352- Management science", "MGMT 385- Human resource Management", "MGMT 420- Project Management", "MGMT431- Organization design and structures",
    "MGMT 446- Leadership and Mgrl behavior", "MGMT 447- Training and development", "MGMT 474- Mgmts responsibility society", "MGMT 485- Organizational change and development"
    , "MGMT 495- Internship in management"};

    String[] harvardCourseBreakdownCS = new String[]{"CS 121- Introduction to theoretical computer science", " CS 124- Data structures and algorithms"
    , "CS 20- Discrete Mathematics for computer science", "AM 106- Applied Algebra", "AM 107- Theory of computation", "-- Select 2 --"
    , "CS 50- Introduction to Computer Science", "CS 51- Abstraction and Design in computation", "CS 61- Systems programming and machine organization"};

    String[] harvardCourseBreakdownBM = new String[]{"Finance 1", "Finance 2", "Financial reporting and control (FRC)", "Leadership and organizational behavior (LEAD)"
    , "Marketing", "Technology and Operations management (TOM)", "Business, Government, and the international economy (BGIE)", "The entrepreneurial manager (TEM)"
    , "Leadership and Corporate Accountability (LCA)", "FIELD global immersion"};

    String[] isuCourseBreakdownCS = new String[]{"COM 223- Small group processes", "ENG 249- Technical and professional writing"
    , "IT 168- Structured problem solving using the computer", "IT 179- Introduction to data structures", "IT 180- C++ Programming", "IT 214- Social, legal, and ethical issues in information technology"
    , "IT 225- Computer Organization", "IT 261- Systems development 1", "IT 279- Algorithms and Data Structures", "IT 326- Principles of software engineering", "IT 327- Concepts of programming languages"
    , "IT 378- Database processing", "IT 383- Principles of operating systems", "IT 386- Intro to networking and parallel and distributed computing"
    , "IT 398- Professional practice in information technology", "MAT 145- Calculus 1", "MAT 146- Calculus 2", "MAT 260- Discrete Mathematics"};

    String[] isuCourseRequirementsMinorMath = new String[]{"MAT 145 - Calculus I", "MAT 146 - Calculus II", "Select 4---", "MAT 147 - Calculus III",
            "MAT 175 - Elementary Linear Algebra", "MAT 236 - Elementary Abstract Algebra", "MAT 247 - Elementary Real Analysis", "MAT 260 - Discrete Mathematics"
            , "MAT 268 - Introduction To Undergraduate Research In Mathematics", "MAT 330 - Number Theory", "MAT 336 - Advanced Abstract Algebra"
            , "MAT 337 - Advanced Linear Algebra", "MAT 340 - Differential Equations I", "MAT 341 - Differential Equations II", "MAT 345 - Advanced Calculus"
            , "MAT 347 - Advanced Real Analysis", "MAT 350 - Applied Probability Models", "MAT 351 - Statistics And Data Analysis"
            , "MAT 361 - Topics In Discrete Mathematics", "MAT 362 - Linear Optimization", "MAT 363 - Graph Theory", "End Select 4---"};

    String[] isuCourseRequirementsMinorPsych = new String[]{"Select 1---", "PSY 110 - Fundamentals Of Psychology", "PSY 111 - Introduction To Psychology", "End Select 1---"
            , "PSY 231 - Research Methods In Psychology", "PSY 233 - Psychology Of Personality", "Select 1---", "PSY 138 - Reasoning In Psychology Using Statistics"
            , "ECO 138 - Economic Reasoning Using Statistics", "POL 138 - Quantitative Reasoning In Political Science", "MQM 100 - Statistical Reasoning"
            , "MAT 150 - Fundamentals Of Statistical Reasoning", "SOC 275 - Social Statistics", "End Select 1---"};

    String[] eiuCourseRequirementsMinorMath = new String[]{"MAT 1441G - Calculus and Analytic Geometry I", "MAT 2442 - Calculus and Analytic Geometry II"
            , "MAT 2443 - Calculus and Analytic Geometry III", "Electives in mathematics selected in consultation with a math advisor"};

    String[] eiuCourseRequirementsMinorPsych = new String[]{"PSY 1879G - Introductory Psychology", "Select 2---"
            , "PSY 3590 - Theories of Personality", "PSY 3780 - Abnormal Psychology", "PSY 3870 - Social Psychology"
            , "PSY 3310 - Biological Psychology", "PSY 3450 - Neuropsychology", "PSY 3680 - Sensation and Perception"
            , "PSY 3820 - Cognitive Neuroscience", "PSY 3620 - Psychology of Learning", "PSY 3710 - Human Memory"
            , "PSY 3830 - Cognitive Psychology", "PSY 3515 - Child Psychology", "PSY 3521 - Psychology of Adolescence and Young Adulthood"
            , "PSY 3525 - Psychology of Maturity and Old Age", "Electives in Psychology selected to meet the particular educational goals of individual students in consultation with a Psychology advisor"};

    String[] nwuCourseRequirementsMinorMath = new String[]{"Select 1 Group---", "Begin Group I"
            , "MATH 220-0 Differential Calculus of One-Variable Functions", "MATH 224-0 Differential Calculus of One-Variable Functions Integral Calculus of One-Variable Functions"
            , "End Group I", "Begin Group II", "MATH 212-0 Single Variable Calculus I", "MATH 213-0 Single Variable Calculus II"
            , "MATH 214-0 Single Variable Calculus III", "End Group II", "End Select 1 Group---"};

    String[] nwuCourseRequirementsMinorPsych = new String[]{"PSYCH 110-0 Introduction to Psychology"
            , "PSYCH 201-0 Statistical Methods in Psychology (or approved substitute)", "PSYCH 205-0 Research Methods in Psychology"
            , "Select 1---", "PSYCH 204-0 Social Psychology", "PSYCH 215-0 Psychology of Personality", "PSYCH 303-0 Psychopathology"
            , "PSYCH 315-0 Special Topics in Social/Clinical/Personality", "PSYCH 326-0 Social and Personality Development"
            , "PSYCH 357-0 Advanced Seminar in Personality, Clinical, or Social Psychology", "PSYCH 384-0 Close Relationships"
            , "End Select 1---", "Select 1---", "PSYCH 212-0 Introduction to Neuroscience", "PSYCH 228-0 Cognitive Psychology"
            , "PSYCH 312-1 Selected Topics in Neuroscience and Psychophysiology", "PSYCH 316-0 Special Topics in Cognition/Neuroscience"
            , "PSYCH 324-0 Perception", "PSYCH 333-0 Psychology of Thinking", "PSYCH 336-0 Consciousness", "PSYCH 346-0 Psychology of Instructional Design and Technology"
            , "PSYCH 358-0 Advanced Seminar in Cognition or Neuroscience", "PSYCH 361-0 Brain Damage and the Mind"
            , "PSYCH 362-0 Cogntive Development", "PSYCH 363-0 Images of Cognition", "PSYCH 365-0 Brain and Cognition"
            , "COG_SCI 210-0 Language and the Brain", "COG_SCI 211-0 Learning, Representation & Reasoning", "End Select 1---"
            , "At least 1 200-level psychology department course", "At least 2 300-level psychology department courses"};

    String[] huCourseRequirementsMinorMath = new String[]{"No minor available", "N/A"};

    String[] huCourseRequirementsMinorPsych = new String[]{"No minor available", "N/A"};

    String[] uiCourseRequirementsMinorMath = new String[]{"MATH 241 - Calculus III", "Select 5---"
            , "MATH 347 - Fundamental Mathematics", "ASRM 406 - Linear Algebra with Financial Applications (formerly MATH 410)"
            , "MATH 415 - Applied Linear Algebra", "MATH 416 - Abstract Linear Algebra", "MATH 417 - Intro to Abstract Algebra"
            , "MATH 418 - Intro to Abstract Algebra II", "MATH 427 - Honors Abstract Algebra", "MATH 453 - Elementary Theory of Numbers"
            , "MATH 412 - Graph Theory", "MATH 413 - Intro to Combinatorics", "MATH 414 - Mathematical Logic",
            "MATH 482 - Linear Programming", "MATH 284 - Intro Differential Systems", "MATH 285 - Intro Differential Equations"
            , "MATH 286 - Intro to Differential Eq Plus", "MATH 424 - Honors Real Analysis", "MATH 425 - Honors Advanced Analysis"
            , "MATH 441 - Differential Equations", "MATH 442 - Intro Partial Diff Equations", "MATH 444 - Elementary Real Analysis"
            , "MATH 446 - Applied Complex Variables", "MATH 447 - Real Variables", "MATH 448 - Complex Variables",
            "CS 450 - Numerical Analysis", "MATH 484 - Nonlinear Programming", "MATH 487 - Advanced Engineering Math",
            "MATH 489 - Dynamics & Differential Eqns", "MATH 402 - Non Euclidean Geometry", "MATH 403 - Euclidean Geometry",
            "MATH 423 - Differential Geometry", "MATH 428 - Honors Topics in Mathematics", "MATH 432 - Set Theory and Topology",
            "MATH 481 - Vector and Tensor Analysis", "MATH 461 - Probability Theory", "STAT 400 - Statistics and Probability I",
            "STAT 410 - Statistics and Probability II", "STAT 420 - Methods of Applied Statistics", "End Select 5---"};


    String[] uiCourseRequirementsMinorPsych = new String[]{"PSYC 100 - Intro Psych", "PSYC 235 - Intro to Statistics (or equivalent)"
            , "Select 1---", "PSYC 204 - Intro to Brain and Cognition", "PSYC 210 - Behavioral Neuroscience", "PSYC 220 - Images of Mind"
            , "PSYC 224 - Cognitive Psych", "PSYC 230 - Perception & Sensory Processes", "PSYC 248 - Learning and Memory",
            "End Select 1---", "Select 1---", "PSYC 201 - Intro to Social Psych", "PSYC 216 - Child Psych"
            , "PSYC 238 - Psychopathology and Problems in Living", "PSYC 239 - Community Psych", "PSYC 245 - Industrial Org Psych"
            , "PSYC 250 - Psych of Personality", "End Select 1---", "Select two 300- or 400- level Psychology courses"};

    String[] siuCourseRequirementsMinorMath = new String[]{"No minor available", "N/A"};

    String[] siuCourseRequirementsMinorPsych = new String[]{"Select 1 Group---", "Select 5---", "Begin Group I", "PSYC 233", "PSYC 237"
            , "PSYC 301", "PSYC 303", "PSYC 304", "PSYC 305", "PSYC 306", "PSYC 307", "PSYC 331", "PSYC 333", "PSYC 334", "PSYC 431"
            , "PSYC 432", "PSYC 440", "PSYC 451", "PSYC 461", "PSYC 464", "PSYC 470", "CI 403", "PSYC 408", "End Group I"
            , "Begin Group II", "PSYC 302", "PSYC 308", "PSYC 309", "PSYC 310", "PSYC 312", "PSYC 345", "PSYC 402", "PSYC 407"
            , "PSYC 409", "PSYC 415", "PSYC 416", "PSYC 419", "PSYC 445", "PSYC 471", "End Group II", "Begin Group III", "PSYC 223"
            , "PSYC 314", "PSYC 322", "PSYC 323", "PSYC 340", "PSYC 411", "PSYC 413", "PSYC 420", "PSYC 421", "PSYC 425", "PSYC 441"
            , "PSYC 465", "End Group III", "Begin Group IV", "PSYC 222", "PSYC 389", "PSYC 391", "PSYC 392", "PSYC 393", "PSYC 394"
            , "PSYC 489", "PSYC 499A&B", "Math 282", "EPSY 402", "End Group IV", "End Select 5---"};

    String[] isuCourseBreakdownBM = new String[]{"ACC 131- Financial Accounting" , "ACC 132- Managerial Accounting", "ACC 270- Information Systems in Organizations"
    , "BUS 100- Enterprise", "BUS 285- Business fundamentals exam", "ECO 101- Principles of Microeconomics", "ECO 102- Principles of Macroeconomics"
    , "FIL 185- Legal, ethical, and social environment of business", "FIL 240- Business Finance", "MKT 230- Introduction to marketing management",
    "MQM 100- Statistical reasoning", "MQM 220- Business organization and management", "MQM 227- Operations Management", "MQM 385- Organizational Strategy"
    , "MQM 221- Organizational behavior and administration", "MQM 335- Operations analytics-Quality management", "ACC 230- Cost and management accounting"
    , "ACC 255- Electronic business management", "MKT 232- Marketing Research"};

    double[] ISU  = {15319, 9850, 21039, 68.8};
    double[] SIU  = {9638, 10622, 14554, 50.0};
    double[] UIUC  = {21956, 12252, 44087, 88.0};
    double[] NU  = {56232, 17019, 21000, 94.0};
    double[] EIU  = {9241.2, 9882, 7806, 57.0};
    double[] HU  = {49653, 11364, 36012, 98.0};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create the button and set a listener to move to cost activity
        Button startbtn = (Button)findViewById(R.id.button);
        startbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //Get each school choice and place into string
                num1 = findViewById(R.id.userChoice1);
                school1 = num1.getText().toString();
                num2 = findViewById(R.id.userChoice2);
                school2 = num2.getText().toString();
                num3 = findViewById(R.id.userChoice3);
                school3 = num3.getText().toString();
                numChoices = getNumChoices();
                majorholder = findViewById(R.id.userMajor);
                major = majorholder.getText().toString();
                minorholder = findViewById(R.id.userMinor);
                minor = minorholder.getText().toString();
                openCostActivity();

            }
            });
    }

    /*
    //Call this method 3 times, once for each school, to populate the cost screens (Same idea for course screen)
    public void fillCost(String school, int schoolchoice){
        TextView schoolName1 = (TextView) findViewById(R.id.schoolName);
        TextView inStateTuition = (TextView) findViewById((R.id.inStateTuitionCost));
        TextView onCampusLiving = (TextView) findViewById(R.id.onCampusLivingCost);
        TextView studentSize = (TextView) findViewById(R.id.studentSize);
        TextView gradPercent = (TextView) findViewById(R.id.gradPercent);
        TextView schoolName2 = (TextView) findViewById(R.id.schoolName2);
        TextView inStateTuition2 = (TextView) findViewById((R.id.inStateTuitionCost2));
        TextView onCampusLiving2 = (TextView) findViewById(R.id.onCampusLivingCost2);
        TextView studentSize2 = (TextView) findViewById(R.id.studentSize2);
        TextView gradPercent2 = (TextView) findViewById(R.id.gradPercent2);
        TextView schoolName3 = (TextView) findViewById(R.id.schoolName3);
        TextView inStateTuition3 = (TextView) findViewById((R.id.inStateTuitionCost3));
        TextView onCampusLiving3 = (TextView) findViewById(R.id.onCampusLivingCost3);
        TextView offCampusliving3 = (TextView) findViewById(R.id.offCampusLivingCost3);
        TextView studentSize3 = (TextView) findViewById(R.id.studentSize3);
        TextView gradPercent3 = (TextView) findViewById(R.id.gradPercent3);

      switch(school){
          case "University of Illinois":
              if(schoolchoice == 1){
                  schoolName1.setText("University of Illinois:");
                  String tuition = Double.toString(UIUC[0]);
                  String costLiving = Double.toString(UIUC[1]);
                  String numStudents = Double.toString(UIUC[2]);
                  String gradRate = Double.toString(UIUC[3]);
                  gradRate += "%";
                  inStateTuition.setText(tuition);
                  onCampusLiving.setText(costLiving);
                  studentSize.setText(numStudents);
                  gradPercent.setText(gradRate);
              }
              else if (schoolchoice == 2){
                  schoolName2.setText("University of Illinois:");
                  String tuition = Double.toString(UIUC[0]);
                  String costLiving = Double.toString(UIUC[1]);
                  String numStudents = Double.toString(UIUC[2]);
                  String gradRate = Double.toString(UIUC[3]);
                  gradRate += "%";
                  inStateTuition2.setText(tuition);
                  onCampusLiving2.setText(costLiving);
                  studentSize2.setText(numStudents);
                  gradPercent2.setText(gradRate);
              }
              else {
                  schoolName3.setText("University of Illinois:");
                  String tuition = Double.toString(UIUC[0]);
                  String costLiving = Double.toString(UIUC[1]);
                  String numStudents = Double.toString(UIUC[2]);
                  String gradRate = Double.toString(UIUC[3]);
                  gradRate += "%";
                  inStateTuition3.setText(tuition);
                  onCampusLiving3.setText(costLiving);
                  studentSize3.setText(numStudents);
                  gradPercent3.setText(gradRate);
              }
              break;
          case "Southern Illinois University":
              if(schoolchoice == 1){
                  schoolName1.setText("Southern Illinois University:");
                  String tuition = Double.toString(SIU[0]);
                  String costLiving = Double.toString(SIU[1]);
                  String numStudents = Double.toString(SIU[2]);
                  String gradRate = Double.toString(SIU[3]);
                  gradRate += "%";
                  inStateTuition.setText(tuition);
                  onCampusLiving.setText(costLiving);
                  studentSize.setText(numStudents);
                  gradPercent.setText(gradRate);
              }
              else if(schoolchoice == 2){
                  schoolName2.setText("Southern Illinois University:");
                  String tuition = Double.toString(SIU[0]);
                  String costLiving = Double.toString(SIU[1]);
                  String numStudents = Double.toString(SIU[2]);
                  String gradRate = Double.toString(SIU[3]);
                  gradRate += "%";
                  inStateTuition2.setText(tuition);
                  onCampusLiving2.setText(costLiving);
                  studentSize2.setText(numStudents);
                  gradPercent2.setText(gradRate);
              }
              else{
                  schoolName3.setText("Southern Illinois University:");
                  String tuition = Double.toString(SIU[0]);
                  String costLiving = Double.toString(SIU[1]);
                  String numStudents = Double.toString(SIU[2]);
                  String gradRate = Double.toString(SIU[3]);
                  gradRate += "%";
                  inStateTuition3.setText(tuition);
                  onCampusLiving3.setText(costLiving);
                  studentSize3.setText(numStudents);
                  gradPercent3.setText(gradRate);
              }
              break;
          case "Illinois State University":
              if(schoolchoice == 1){
                  schoolName1.setText("Illinois State University:");
                  String tuition = Double.toString(ISU[0]);
                  String costLiving = Double.toString(ISU[1]);
                  String numStudents = Double.toString(ISU[2]);
                  String gradRate = Double.toString(ISU[3]);
                  gradRate += "%";
                  inStateTuition.setText(tuition);
                  onCampusLiving.setText(costLiving);
                  studentSize.setText(numStudents);
                  gradPercent.setText(gradRate);
              }
              else if(schoolchoice ==2){
                  schoolName2.setText("Illinois State University:");
                  String tuition = Double.toString(ISU[0]);
                  String costLiving = Double.toString(ISU[1]);
                  String numStudents = Double.toString(ISU[2]);
                  String gradRate = Double.toString(ISU[3]);
                  gradRate += "%";
                  inStateTuition2.setText(tuition);
                  onCampusLiving2.setText(costLiving);
                  studentSize2.setText(numStudents);
                  gradPercent2.setText(gradRate);
              }
              else{
                  schoolName3.setText("Illinois State University:");
                  String tuition = Double.toString(ISU[0]);
                  String costLiving = Double.toString(ISU[1]);
                  String numStudents = Double.toString(ISU[2]);
                  String gradRate = Double.toString(ISU[3]);
                  gradRate += "%";
                  inStateTuition3.setText(tuition);
                  onCampusLiving3.setText(costLiving);
                  studentSize3.setText(numStudents);
                  gradPercent3.setText(gradRate);
              }
              break;
          case "Harvard":
              if(schoolchoice == 1){
                  schoolName1.setText("Harvard University:");
                  String tuition = Double.toString(HU[0]);
                  String costLiving = Double.toString(HU[1]);
                  String numStudents = Double.toString(HU[2]);
                  String gradRate = Double.toString(HU[3]);
                  gradRate += "%";
                  inStateTuition.setText(tuition);
                  onCampusLiving.setText(costLiving);
                  studentSize.setText(numStudents);
                  gradPercent.setText(gradRate);
              }
              else if(schoolchoice == 2){
                  schoolName2.setText("Harvard University:");
                  String tuition = Double.toString(HU[0]);
                  String costLiving = Double.toString(HU[1]);
                  String numStudents = Double.toString(HU[2]);
                  String gradRate = Double.toString(HU[3]);
                  gradRate += "%";
                  inStateTuition2.setText(tuition);
                  onCampusLiving2.setText(costLiving);
                  studentSize2.setText(numStudents);
                  gradPercent2.setText(gradRate);
              }
              else{
                  schoolName3.setText("Harvard University:");
                  String tuition = Double.toString(HU[0]);
                  String costLiving = Double.toString(HU[1]);
                  String numStudents = Double.toString(HU[2]);
                  String gradRate = Double.toString(HU[3]);
                  gradRate += "%";
                  inStateTuition3.setText(tuition);
                  onCampusLiving3.setText(costLiving);
                  studentSize3.setText(numStudents);
                  gradPercent3.setText(gradRate);
              }
              break;
          case "Northwestern":
              if(schoolchoice == 1){
                  schoolName1.setText("Northwestern University:");
                  String tuition = Double.toString(NU[0]);
                  String costLiving = Double.toString(NU[1]);
                  String numStudents = Double.toString(NU[2]);
                  String gradRate = Double.toString(NU[3]);
                  gradRate += "%";
                  inStateTuition.setText(tuition);
                  onCampusLiving.setText(costLiving);
                  studentSize.setText(numStudents);
                  gradPercent.setText(gradRate);
              }
              else if (schoolchoice == 2){
                  schoolName2.setText("Northwestern University:");
                  String tuition = Double.toString(NU[0]);
                  String costLiving = Double.toString(NU[1]);
                  String numStudents = Double.toString(NU[2]);
                  String gradRate = Double.toString(NU[3]);
                  gradRate += "%";
                  inStateTuition2.setText(tuition);
                  onCampusLiving2.setText(costLiving);
                  studentSize2.setText(numStudents);
                  gradPercent2.setText(gradRate);
              }
              else {
                  schoolName3.setText("Northwestern University:");
                  String tuition = Double.toString(NU[0]);
                  String costLiving = Double.toString(NU[1]);
                  String numStudents = Double.toString(NU[2]);
                  String gradRate = Double.toString(NU[3]);
                  gradRate += "%";
                  inStateTuition3.setText(tuition);
                  onCampusLiving3.setText(costLiving);
                  studentSize3.setText(numStudents);
                  gradPercent3.setText(gradRate);
              }
              break;
          case "Eastern Illinois University":
              if(schoolchoice == 1){
                  schoolName1.setText("Eastern Illinoi University:");
                  String tuition = Double.toString(EIU[0]);
                  String costLiving = Double.toString(EIU[1]);
                  String numStudents = Double.toString(EIU[2]);
                  String gradRate = Double.toString(EIU[3]);
                  gradRate += "%";
                  inStateTuition.setText(tuition);
                  onCampusLiving.setText(costLiving);
                  studentSize.setText(numStudents);
                  gradPercent.setText(gradRate);
              }
              else if (schoolchoice == 2){
                  schoolName2.setText("Eastern Illinoi University:");
                  String tuition = Double.toString(EIU[0]);
                  String costLiving = Double.toString(EIU[1]);
                  String numStudents = Double.toString(EIU[2]);
                  String gradRate = Double.toString(EIU[3]);
                  gradRate += "%";
                  inStateTuition2.setText(tuition);
                  onCampusLiving2.setText(costLiving);
                  studentSize2.setText(numStudents);
                  gradPercent2.setText(gradRate);
              }
              else{
                  schoolName3.setText("Eastern Illinoi University:");
                  String tuition = Double.toString(EIU[0]);
                  String costLiving = Double.toString(EIU[1]);
                  String numStudents = Double.toString(EIU[2]);
                  String gradRate = Double.toString(EIU[3]);
                  gradRate += "%";
                  inStateTuition3.setText(tuition);
                  onCampusLiving3.setText(costLiving);
                  studentSize3.setText(numStudents);
                  gradPercent3.setText(gradRate);
              }
              break;
          default:
              break;
      }
    }


    public void fillCourse(String school, int schoolchoice, String major, String minor){
        TextView courseTitle = (TextView) findViewById(R.id.coursebreakdownTitle);
        TextView majorBreakdown = (TextView) findViewById(R.id.majorbreakdown);
        TextView minorBreakdown = (TextView) findViewById((R.id.minorbreakdown));
        TextView courseTitle2 = (TextView) findViewById(R.id.coursebreakdownTitle2);
        TextView majorBreakdown2 = (TextView) findViewById(R.id.majorbreakdown2);
        TextView minorBreakdown2 = (TextView) findViewById((R.id.minorbreakdown2));
        TextView courseTitle3 = (TextView) findViewById(R.id.coursebreakdownTitle3);
        TextView majorBreakdown3 = (TextView) findViewById(R.id.majorbreakdown3);
        TextView minorBreakdown3 = (TextView) findViewById((R.id.minorbreakdown3));

        switch(school){
            case "University of Illinois":
                if(schoolchoice == 1){
                    courseTitle.setText("Breakdown of course requirements for University of Illinois");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < illinoisCourseBreakdownCS.length; i++){
                                csMajorholder += illinoisCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown.setText(csMajorholder);
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<illinoisCourseBreakdownBM.length; i++){
                                bmMajorholder += illinoisCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<uiCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += uiCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<uiCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += uiCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else if(schoolchoice == 2){
                    courseTitle2.setText("Breakdown of course requirements for University of Illinois");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < illinoisCourseBreakdownCS.length; i++){
                                csMajorholder += illinoisCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown2.setText(csMajorholder);
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<illinoisCourseBreakdownBM.length; i++){
                                bmMajorholder += illinoisCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown2.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<uiCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += uiCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<uiCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += uiCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else{
                    courseTitle3.setText("Breakdown of course requirements for University of Illinois");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < illinoisCourseBreakdownCS.length; i++){
                                csMajorholder += illinoisCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown3.setText(csMajorholder);
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<illinoisCourseBreakdownBM.length; i++){
                                bmMajorholder += illinoisCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown3.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<uiCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += uiCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<uiCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += uiCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                break;
            case "Southern Illinois University":
                if(schoolchoice == 1){
                    courseTitle.setText("Breakdown of course requirements for Southern Illinois University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < siuCourseBreakdownCS.length; i++){
                                csMajorholder += siuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<siuCourseBreakdownBM.length; i++){
                                bmMajorholder += siuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<siuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += siuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<siuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += siuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else if (schoolchoice == 2){
                    courseTitle2.setText("Breakdown of course requirements for Southern Illinois University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < siuCourseBreakdownCS.length; i++){
                                csMajorholder += siuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown2.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<siuCourseBreakdownBM.length; i++){
                                bmMajorholder += siuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown2.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<siuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += siuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<siuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += siuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }

                }
                else{
                    courseTitle3.setText("Breakdown of course requirements for Southern Illinois University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < siuCourseBreakdownCS.length; i++){
                                csMajorholder += siuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown3.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<siuCourseBreakdownBM.length; i++){
                                bmMajorholder += siuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown3.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<siuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += siuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<siuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += siuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                break;
            case "Illinois State University":
                if(schoolchoice == 1){
                    courseTitle.setText("Breakdown of course requirements for Illinois State University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < isuCourseBreakdownCS.length; i++){
                                csMajorholder += isuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<isuCourseBreakdownBM.length; i++){
                                bmMajorholder += isuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<isuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += isuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<isuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += isuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else if (schoolchoice == 2){
                    courseTitle2.setText("Breakdown of course requirements for Illinois State University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < isuCourseBreakdownCS.length; i++){
                                csMajorholder += isuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown2.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<isuCourseBreakdownBM.length; i++){
                                bmMajorholder += isuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown2.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<isuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += isuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<isuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += isuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else{
                    courseTitle3.setText("Breakdown of course requirements for Illinois State University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < isuCourseBreakdownCS.length; i++){
                                csMajorholder += isuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown3.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<isuCourseBreakdownBM.length; i++){
                                bmMajorholder += isuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown3.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<isuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += isuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<isuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += isuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                break;
            case "Harvard":
                if(schoolchoice == 1){
                    courseTitle.setText("Breakdown of course requirements for Harvard University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < harvardCourseBreakdownCS.length; i++){
                                csMajorholder += harvardCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<harvardCourseBreakdownBM.length; i++){
                                bmMajorholder += harvardCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<huCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += huCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<huCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += huCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else if (schoolchoice == 2){
                    courseTitle2.setText("Breakdown of course requirements for Harvard University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < harvardCourseBreakdownCS.length; i++){
                                csMajorholder += harvardCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown2.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<harvardCourseBreakdownBM.length; i++){
                                bmMajorholder += harvardCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown2.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<huCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += huCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<huCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += huCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else{
                    courseTitle3.setText("Breakdown of course requirements for Harvard University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < harvardCourseBreakdownCS.length; i++){
                                csMajorholder += harvardCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown3.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<harvardCourseBreakdownBM.length; i++){
                                bmMajorholder += harvardCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown3.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<huCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += huCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<huCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += huCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                break;
            case "Northwestern":
                if(schoolchoice == 1){
                    courseTitle.setText("Breakdown of course requirements for Northwestern University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < northwesternCourseBreakdownCS.length; i++){
                                csMajorholder += northwesternCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<northwesternCourseBreakdownBM.length; i++){
                                bmMajorholder += northwesternCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<nwuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += nwuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<nwuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += nwuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else if (schoolchoice == 2){
                    courseTitle2.setText("Breakdown of course requirements for Northwestern University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < northwesternCourseBreakdownCS.length; i++){
                                csMajorholder += northwesternCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown2.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<northwesternCourseBreakdownBM.length; i++){
                                bmMajorholder += northwesternCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown2.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<nwuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += nwuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<nwuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += nwuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else{
                    courseTitle3.setText("Breakdown of course requirements for Northwestern University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < northwesternCourseBreakdownCS.length; i++){
                                csMajorholder += northwesternCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown3.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<northwesternCourseBreakdownBM.length; i++){
                                bmMajorholder += northwesternCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown3.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<nwuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += nwuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<nwuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += nwuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                break;
            case "Eastern Illinois University":
                if(schoolchoice == 1){
                    courseTitle.setText("Breakdown of course requirements for Eastern Illinois University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < eiuCourseBreakdownCS.length; i++){
                                csMajorholder += eiuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<eiuCourseBreakdownBM.length; i++){
                                bmMajorholder += eiuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<eiuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += eiuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<eiuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += eiuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else if (schoolchoice == 2){
                    courseTitle2.setText("Breakdown of course requirements for Eastern Illinois University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < eiuCourseBreakdownCS.length; i++){
                                csMajorholder += eiuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown2.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<eiuCourseBreakdownBM.length; i++){
                                bmMajorholder += eiuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown2.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<eiuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += eiuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<eiuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += eiuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown2.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                else{
                    courseTitle3.setText("Breakdown of course requirements for Eastern Illinois University:");
                    switch(major){
                        case "Computer Science":
                            String csMajorholder = "";
                            for(int i =0; i < eiuCourseBreakdownCS.length; i++){
                                csMajorholder += eiuCourseBreakdownCS[i];
                                csMajorholder += "\n";
                            }
                            majorBreakdown3.setText(csMajorholder);
                            break;
                        case "Business Management":
                            String bmMajorholder = "";
                            for(int i =0; i<eiuCourseBreakdownBM.length; i++){
                                bmMajorholder += eiuCourseBreakdownBM[i];
                                bmMajorholder += "\n";
                            }
                            majorBreakdown3.setText(bmMajorholder);
                        default:
                            break;
                    }
                    switch(minor){
                        case "Mathematics":
                            String mathMinorHolder = "";
                            for(int i =0; i<eiuCourseRequirementsMinorMath.length;i++){
                                mathMinorHolder += eiuCourseRequirementsMinorMath[i];
                                mathMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(mathMinorHolder);
                            break;
                        case "Psychology":
                            String PsychMinorHolder = "";
                            for(int i =0; i<eiuCourseRequirementsMinorPsych.length; i++){
                                PsychMinorHolder += eiuCourseRequirementsMinorPsych[i];
                                PsychMinorHolder += "\n";
                            }
                            minorBreakdown3.setText(PsychMinorHolder);
                            break;
                        default:
                            break;
                    }
                }
                break;
            default:
                break;
        }
    }
    */

    /*
    //Function to implement multithreading where each thread handles parsing for 1 school choice (out of 3)
    public void startThreads(int numChoices){
            Handler handler = new Handler();
            for(int i = 0; i < numChoices; i++){
                final int schoolChoice = i;
                Runnable runobj = new Runnable(){
                    //This run method executes the runnable interface and allows for multi threading
                    @Override
                    public void run(){
                        System.out.println("Debug message");
                        //We will send the school choice to another method to parse the info and send it to appropriate layouts
                      //  parseInfo(schoolChoice);
                    };
                };
                //Handler will place each new thread in queue to be ran
                handler.post(runobj);
            }
    }

    //Method that takes the parsed URL and breaks it down to a workable URL
    public void parseInfo(String schoolurl){
        System.out.print("This is placeholder for school Choice ");
        System.out.println(schoolurl);
        //Loop through the url and find the places where cuts can be made
        for(int i = 0; i <schoolurl.length();i++){
            String removeFirst = schoolurl.substring(i, i+1); //Set string equal to the individual substring components
           // System.out.println("The value of removefirst is ");
           // System.out.println(removeFirst);
            if(removeFirst.equals(".")){ //Check for unneeded periods (indicated exproxy was added to URL)
                for(int l = i; l <schoolurl.length(); l++){ //Start parsing at the period and loop to the end of URL
                    String urlholder = schoolurl.substring(l, l+1); //Set string equal to individual components to check for unneeded login info at end
                 //   System.out.println("Found urlholder to be ");
                 //   System.out.println(urlholder);
                    if(urlholder.equals("/")){ //If unneeded info found at the end of the URL then it is removed and newurl is used for parsing purposes
                        String newurl = schoolurl.substring(i+1, l+1);
                        System.out.println("The new url we found is ");
                        System.out.println(newurl);
                    }
                }
                break;
            }
        }
    } */

    //Function to open the initial cost activity class
    public void openCostActivity(){
        Intent intent = new Intent(this, costActivity.class);
        intent.putExtra("ISUArray", ISU);
        intent.putExtra("NWUArray", NU);
        intent.putExtra("HUArray", HU);
        intent.putExtra("SIUArray", SIU);
        intent.putExtra("EIUArray", EIU);
        intent.putExtra("UIUCArray", UIUC);
        intent.putExtra("ISUCS", isuCourseBreakdownCS);
        intent.putExtra("ISUBM", isuCourseBreakdownBM);
        intent.putExtra("NWUCS", northwesternCourseBreakdownCS);
        intent.putExtra("NWUBM", northwesternCourseBreakdownBM);
        intent.putExtra("HUCS", harvardCourseBreakdownCS);
        intent.putExtra("HUBM", harvardCourseBreakdownBM);
        intent.putExtra("SIUCS", siuCourseBreakdownCS);
        intent.putExtra("SIUBM", siuCourseBreakdownBM);
        intent.putExtra("EIUCS", eiuCourseBreakdownCS);
        intent.putExtra("EIUBM", eiuCourseBreakdownBM);
        intent.putExtra("UIUCCS", illinoisCourseBreakdownCS);
        intent.putExtra("UIUCBM", illinoisCourseBreakdownBM);
        intent.putExtra("School1", school1);
        intent.putExtra("School2", school2);
        intent.putExtra("School3", school3);
        intent.putExtra("Major", major);
        intent.putExtra("Minor", minor);
        intent.putExtra("ISUMathMinor", isuCourseRequirementsMinorMath);
        intent.putExtra("ISUPsychMinor", isuCourseRequirementsMinorPsych);
        intent.putExtra("SIUMathMinor", siuCourseRequirementsMinorMath);
        intent.putExtra("SIUPsychMinor", siuCourseRequirementsMinorPsych);
        intent.putExtra("EIUMathMinor", eiuCourseRequirementsMinorMath);
        intent.putExtra("EIUPsychMinor", eiuCourseRequirementsMinorPsych);
        intent.putExtra("NWUMathMinor", nwuCourseRequirementsMinorMath);
        intent.putExtra("NWUPsychMinor", nwuCourseRequirementsMinorPsych);
        intent.putExtra("UIUCMathMinor", uiCourseRequirementsMinorMath);
        intent.putExtra("UIUCPsychMinor", uiCourseRequirementsMinorPsych);
        intent.putExtra("HUMathMinor", huCourseRequirementsMinorMath);
        intent.putExtra("HUPsychMinor", huCourseRequirementsMinorPsych);
        startActivity(intent);
    }

    //Function that checks how many school options the user has entered and returns that number
    public int getNumChoices(){
        int returnVal = 3;
        //Check for empty strings, if empty then return value is reduced by 1
        if(school1.matches("")){
            returnVal--;
        }
        if(school2.matches("")){
            returnVal--;
        }
        if(school3.matches("")){
            returnVal--;
        }
        return returnVal;
    }

    /*
    //Function to utilize Volley and download the database URL into a string to be parsed
    public void pullDatabase(){
        System.out.print("Debug message for pull url method");
        //Create the request queue and designate the database URL
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://ezproxy-db.appspot.com/";
        //Create new string request and set equal to the url
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //This function will handle the URL and parse through it to find the appropriate college websites
               // System.out.println(response);
                String responseholder = response;
                findSchool(responseholder);
            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                System.out.print("Problems boss");
            }
        });
        queue.add(stringRequest);
    } */

    /*
    //Method to take the database URL in string format and parse through to find the specified schools
    public String findSchool(String response) {
        //Outer for loop to loop through the entire URL string, starts at 2390 to save time as school URLs start past that point
        for (int i = 2390; i < response.length() - 4; i++) {
            String holderForResponse = response.substring(i, i + 4); //String to capture 4 characters at a time to test if matches tag
            if (holderForResponse.matches("<td>")) { //Check tag
                //If tag is corrrect then loops through string to find the ending tag
                for (int j = i + 4; j < response.length() - 5; j++) {
                    String holderForEndTag = response.substring(j, j + 5); //String to hold 5 characters at a time to test for ending tag
                    if (holderForEndTag.matches("</td>")) { //Check for end tag
                        String findSchool1 = response.substring(i + 4, j); //Place contents between tags into a string
                        if (findSchool1.matches(school1)) { //Check if string matches what we are looking for
                            System.out.print("The first school option we found was: ");
                            System.out.println(findSchool1);
                            for (int y = j + 5; y < response.length(); y++) { //Loop through URL string starting at prior ending tag to find next set of tags
                                String holder3 = response.substring(y, y + 5); //Placeholder used for debugging purposes
                              //  System.out.print("First for loop inside the find first school");
                                //System.out.println(holder3);
                                for (int x = y + 4; x < response.length(); x++) { //Loop through after finding start tag and find the end tag
                                    String holderForEndTag2 = response.substring(x, x + 5);
                                   // System.out.println("Looping inside the value of holder4 is: ");
                                  //  System.out.println(holder4);
                                    if (holderForEndTag2.matches("</td>")) { //Check for end tag
                                        schoolurl1 = response.substring(y + 11, x); //Set new URL string equal to the contents between the two tags
                                        System.out.println("The value of schoolurl1 is ");
                                        System.out.println(schoolurl1);
                                        parseInfo(schoolurl1); //Send the URL to the parseInfo function to reduce URL to workable state
                                        x = response.length(); //Set x and Y to break out of loops
                                        y = response.length();
                                    }
                                }
                            }
                        }
                        if (findSchool1.matches(school2)) {
                            System.out.print("The second school option we found was: ");
                            System.out.println(findSchool1);
                            for (int y = j + 5; y < response.length(); y++) {
                                String holder3 = response.substring(y, y + 5);
                                for (int x = y + 4; x < response.length(); x++) {
                                    String holder4 = response.substring(x, x + 5);
                                    if (holder4.matches("</td>")) {
                                        schoolurl2 = response.substring(y + 11, x);
                                        System.out.println(schoolurl2);
                                        parseInfo(schoolurl2);
                                        x = response.length();
                                        y=response.length();
                                    }
                                }
                            }
                        }
                        if (findSchool1.matches(school3)) {
                            System.out.print("The third school option we found was: ");
                            System.out.println(findSchool1);
                            for (int y = j + 5; y < response.length(); y++) {
                                String holder3 = response.substring(y, y + 5);
                                for (int x = y + 4; x < response.length(); x++) {
                                    String holder4 = response.substring(x, x + 5);
                                    if (holder4.matches("</td>")) {
                                        schoolurl3 = response.substring(y + 11, x);
                                        System.out.println(schoolurl3);
                                        parseInfo(schoolurl3);
                                        x = response.length();
                                        y=response.length();
                                    }
                                }
                            }
                        }
                        j = response.length();
                    }
                }
            }
        }
       // startThreads(numChoices);
        return response;
    }
     */



}
