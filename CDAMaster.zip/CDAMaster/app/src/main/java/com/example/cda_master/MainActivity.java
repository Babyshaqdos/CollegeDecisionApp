package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create the button and set a listener to move to cost activity
        Button startbtn = (Button)findViewById(R.id.button);
        startbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int numChoices = getNumChoices();
                startThreads(numChoices);
                openCostActivity();
            }
            });


    }

    //Function to implement multithreading where each thread handles parsing for 1 school choice (out of 3)
    public void startThreads(int numChoices){
        Handler handler = new Handler();
        for(int i = 0; i < numChoices; i++){
            final int schoolChoice = i;
            Runnable runobj = new Runnable(){
                //This run method executes the runnable interface and allows for multi threading
                @Override
                public void run(){
                    System.out.println("Debug message");
                    //We will send the school choice to another method to parse the info and send it to appropriate layouts
                    parseInfo(schoolChoice);
                };
            };
            //Handler will place each new thread in queue to be ran
            handler.post(runobj);
        }
    }

    //Placeholder method for now
    public void parseInfo(int schoolChoice){
        System.out.print("This is placeholder for school Choice ");
        System.out.println(schoolChoice);
    }


    //Function to open the initial cost activity class
    public void openCostActivity(){
        Intent intent = new Intent(this, costActivity.class);
        startActivity(intent);
    }

    //Function that checks how many school options the user has entered and returns that number
    public int getNumChoices(){
        int returnVal = 3;
        //Get each school choice and place into string
        EditText num1 = findViewById(R.id.userChoice1);
        String school1 = num1.getText().toString();
        EditText num2 = findViewById(R.id.userChoice2);
        String school2 = num2.getText().toString();
        EditText num3 = findViewById(R.id.userChoice3);
        String school3 = num3.getText().toString();
        //Check for empty strings, if empty then return value is reduced by 1
        if(school1.matches("")){
            returnVal--;
        }
        if(school2.matches("")){
            returnVal--;
        }
        if(school3.matches("")){
            returnVal--;
        }
        return returnVal;
    }


}