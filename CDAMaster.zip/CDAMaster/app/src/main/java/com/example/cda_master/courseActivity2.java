package com.example.cda_master;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

public class courseActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coursebreakdown2);
        //Create and set a listener on the layout view to handle the swiping
        View view = findViewById(R.id.courselayout2);
        populateLayout();
        view.setOnTouchListener(new DetectSwiping(courseActivity2.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent = new Intent(courseActivity2.this, courseActivity3.class);
                topIntent.putExtras(getIntent().getExtras());
                startActivity(topIntent);
            }
            public void onSwipeRight(){
                Intent intent = new Intent(courseActivity2.this, costActivity2.class);
                intent.putExtras(getIntent().getExtras());
                startActivity(intent);
            }
            public void onSwipeLeft(){
                //Do Nothing
            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent = new Intent(courseActivity2.this, courseActivity.class);
                downIntent.putExtras(getIntent().getExtras());
                startActivity(downIntent);
            }
        });
    }

    public void populateLayout(){
        TextView courseTitle = (TextView) findViewById(R.id.coursebreakdownTitle2);
        TextView majorBreakdown2 = (TextView) findViewById(R.id.majorbreakdown2);
        TextView minorBreakdown2 = (TextView) findViewById((R.id.minorbreakdown2));
        Intent intent = getIntent();
        String schoolname = intent.getStringExtra("School2");
        String courseTitleholder = "Course requirements at ";
        courseTitleholder += schoolname;
        courseTitle.setText(courseTitleholder);
        String major = intent.getStringExtra("Major");
        String minor = intent.getStringExtra("Minor");
        double[] ISUArray = intent.getDoubleArrayExtra("ISUArray");
        double[] SIUArray = intent.getDoubleArrayExtra("SIUArray");
        double[] NWUArray = intent.getDoubleArrayExtra("NWUArray");
        double[] HUArray = intent.getDoubleArrayExtra("HUArray");
        double[] UIUCArray = intent.getDoubleArrayExtra("UIUCArray");
        double[] EIUArray = intent.getDoubleArrayExtra("EIUArray");
        String[] ISUcoursebreakdownCS = intent.getStringArrayExtra("ISUCS");
        String[] ISUcoursebreakdownBM = intent.getStringArrayExtra("ISUBM");
        String[] SIUcoursebreakdownCS = intent.getStringArrayExtra("SIUCS");
        String[] SIUcoursebreakdownBM = intent.getStringArrayExtra("SIUBM");
        String[] NWUcoursebreakdownCS = intent.getStringArrayExtra("NWUCS");
        String[] NWUcoursebreakdownBM = intent.getStringArrayExtra("NWUBM");
        String[] HUcoursebreakdownCS = intent.getStringArrayExtra("HUCS");
        String[] HUcoursebreakdownBM = intent.getStringArrayExtra("HUBM");
        String[] UIUCcoursebreakdownCS = intent.getStringArrayExtra("UIUCCS");
        String[] UIUCcoursebreakdownBM = intent.getStringArrayExtra("UIUCBM");
        String[] EIUcoursebreakdownCS = intent.getStringArrayExtra("EIUCS");
        String[] EIUcoursebreakdownBM = intent.getStringArrayExtra("EIUBM");
        String[] eiuMathMinor = intent.getStringArrayExtra("EIUMathMinor");
        String[] eiuPsychMinor = intent.getStringArrayExtra("EIUPsychMinor");
        String[] uiucMathMinor = intent.getStringArrayExtra("UIUCMathMinor");
        String[] uiucPsychMinor = intent.getStringArrayExtra("UIUCPsychMinor");
        String[] huMathMinor = intent.getStringArrayExtra("HUMathMinor");
        String[] huPsychMinor = intent.getStringArrayExtra("HUPsychMinor");
        String[] nwuMathMinor = intent.getStringArrayExtra("NWUMathMinor");
        String[] nwuPsychMinor = intent.getStringArrayExtra("NWUPsychMinor");
        String[] isuMathMinor = intent.getStringArrayExtra("ISUMathMinor");
        String[] isuPsychMinor = intent.getStringArrayExtra("ISUPsychMinor");
        String[] siuMathMinor = intent.getStringArrayExtra("SIUMathMinor");
        String[] siuPsychMinor = intent.getStringArrayExtra("SIUPsychMinor");


        switch(schoolname) {
            case "University of Illinois":
                switch (major) {
                    case "Computer Science":
                        String csMajorholder = "";
                        for (int i = 0; i < UIUCcoursebreakdownCS.length; i++) {
                            csMajorholder += UIUCcoursebreakdownCS[i];
                            csMajorholder += "\n";
                        }
                        majorBreakdown2.setText(csMajorholder);
                        break;
                    case "Business Management":
                        String bmMajorholder = "";
                        for (int i = 0; i < UIUCcoursebreakdownBM.length; i++) {
                            bmMajorholder += UIUCcoursebreakdownBM[i];
                            bmMajorholder += "\n";
                        }
                        majorBreakdown2.setText(bmMajorholder);
                        break;
                    default:
                        break;
                }
                switch (minor) {
                    case "Mathematics":
                        String mathMinorHolder = "";
                        for (int i = 0; i < uiucMathMinor.length; i++) {
                            mathMinorHolder += uiucMathMinor[i];
                            mathMinorHolder += "\n";
                        }
                        minorBreakdown2.setText(mathMinorHolder);
                        return;
                    case "Psychology":
                        String PsychMinorHolder = "";
                        for (int i = 0; i < uiucPsychMinor.length; i++) {
                            PsychMinorHolder += uiucPsychMinor[i];
                            PsychMinorHolder += "\n";
                        }
                        minorBreakdown2.setText(PsychMinorHolder);
                        return;
                    default:
                        return;
                }
            case "Southern Illinois University":
                switch (major) {
                    case "Computer Science":
                        String csMajorholder2 = "";
                        for (int i = 0; i < SIUcoursebreakdownCS.length; i++) {
                            csMajorholder2 += SIUcoursebreakdownCS[i];
                            csMajorholder2 += "\n";
                        }
                        majorBreakdown2.setText(csMajorholder2);
                        break;
                    case "Business Management":
                        String bmMajorholder2 = "";
                        for (int i = 0; i < SIUcoursebreakdownBM.length; i++) {
                            bmMajorholder2 += SIUcoursebreakdownBM[i];
                            bmMajorholder2 += "\n";
                        }
                        majorBreakdown2.setText(bmMajorholder2);
                        break;
                    default:
                        break;
                }
                switch (minor) {
                    case "Mathematics":
                        String mathMinorHolder2 = "";
                        for (int i = 0; i < siuMathMinor.length; i++) {
                            mathMinorHolder2 += siuMathMinor[i];
                            mathMinorHolder2 += "\n";
                        }
                        minorBreakdown2.setText(mathMinorHolder2);
                        return;
                    case "Psychology":
                        String PsychMinorHolder2 = "";
                        for (int i = 0; i < siuPsychMinor.length; i++) {
                            PsychMinorHolder2 += siuPsychMinor[i];
                            PsychMinorHolder2 += "\n";
                        }
                        minorBreakdown2.setText(PsychMinorHolder2);
                        return;
                    default:
                        return;
                }
            case "Eastern Illinois University":
                switch (major) {
                    case "Computer Science":
                        String csMajorholder3 = "";
                        for (int i = 0; i < EIUcoursebreakdownCS.length; i++) {
                            csMajorholder3 += EIUcoursebreakdownCS[i];
                            csMajorholder3 += "\n";
                        }
                        majorBreakdown2.setText(csMajorholder3);
                        break;
                    case "Business Management":
                        String bmMajorholder3 = "";
                        for (int i = 0; i < EIUcoursebreakdownBM.length; i++) {
                            bmMajorholder3 += EIUcoursebreakdownBM[i];
                            bmMajorholder3 += "\n";
                        }
                        majorBreakdown2.setText(bmMajorholder3);
                        break;
                    default:
                        break;
                }
                switch (minor) {
                    case "Mathematics":
                        String mathMinorHolder3 = "";
                        for (int i = 0; i < eiuMathMinor.length; i++) {
                            mathMinorHolder3 += eiuMathMinor[i];
                            mathMinorHolder3 += "\n";
                        }
                        minorBreakdown2.setText(mathMinorHolder3);
                        return;
                    case "Psychology":
                        String PsychMinorHolder3 = "";
                        for (int i = 0; i < eiuPsychMinor.length; i++) {
                            PsychMinorHolder3 += eiuPsychMinor[i];
                            PsychMinorHolder3 += "\n";
                        }
                        minorBreakdown2.setText(PsychMinorHolder3);
                        return;
                    default:
                        return;
                }
            case "Illinois State University":
                switch (major) {
                    case "Computer Science":
                        String csMajorholder4 = "";
                        for (int i = 0; i < ISUcoursebreakdownCS.length; i++) {
                            csMajorholder4 += ISUcoursebreakdownCS[i];
                            csMajorholder4 += "\n";
                        }
                        majorBreakdown2.setText(csMajorholder4);
                        break;
                    case "Business Management":
                        String bmMajorholder4 = "";
                        for (int i = 0; i < ISUcoursebreakdownBM.length; i++) {
                            bmMajorholder4 += ISUcoursebreakdownBM[i];
                            bmMajorholder4 += "\n";
                        }
                        majorBreakdown2.setText(bmMajorholder4);
                        break;
                    default:
                        break;
                }
                switch (minor) {
                    case "Mathematics":
                        String mathMinorHolder4 = "";
                        for (int i = 0; i < isuMathMinor.length; i++) {
                            mathMinorHolder4 += isuMathMinor[i];
                            mathMinorHolder4 += "\n";
                        }
                        minorBreakdown2.setText(mathMinorHolder4);
                        return;
                    case "Psychology":
                        String PsychMinorHolder4 = "";
                        for (int i = 0; i < isuPsychMinor.length; i++) {
                            PsychMinorHolder4 += isuPsychMinor[i];
                            PsychMinorHolder4 += "\n";
                        }
                        minorBreakdown2.setText(PsychMinorHolder4);
                        return;
                    default:
                        return;
                }
            case "Northwestern":
                switch (major) {
                    case "Computer Science":
                        String csMajorholder5 = "";
                        for (int i = 0; i < NWUcoursebreakdownCS.length; i++) {
                            csMajorholder5 += NWUcoursebreakdownCS[i];
                            csMajorholder5 += "\n";
                        }
                        majorBreakdown2.setText(csMajorholder5);
                        break;
                    case "Business Management":
                        String bmMajorholder5 = "";
                        for (int i = 0; i < NWUcoursebreakdownBM.length; i++) {
                            bmMajorholder5 += NWUcoursebreakdownBM[i];
                            bmMajorholder5 += "\n";
                        }
                        majorBreakdown2.setText(bmMajorholder5);
                        break;
                    default:
                        break;
                }
                switch (minor) {
                    case "Mathematics":
                        String mathMinorHolder5 = "";
                        for (int i = 0; i < nwuMathMinor.length; i++) {
                            mathMinorHolder5 += nwuMathMinor[i];
                            mathMinorHolder5 += "\n";
                        }
                        minorBreakdown2.setText(mathMinorHolder5);
                        return;
                    case "Psychology":
                        String PsychMinorHolder5 = "";
                        for (int i = 0; i < nwuPsychMinor.length; i++) {
                            PsychMinorHolder5 += nwuPsychMinor[i];
                            PsychMinorHolder5 += "\n";
                        }
                        minorBreakdown2.setText(PsychMinorHolder5);
                        return;
                    default:
                        return;
                }
            case "Harvard":
                switch (major) {
                    case "Computer Science":
                        String csMajorholder6 = "";
                        for (int i = 0; i < HUcoursebreakdownCS.length; i++) {
                            csMajorholder6 += HUcoursebreakdownCS[i];
                            csMajorholder6 += "\n";
                        }
                        majorBreakdown2.setText(csMajorholder6);
                        break;
                    case "Business Management":
                        String bmMajorholder6 = "";
                        for (int i = 0; i < HUcoursebreakdownBM.length; i++) {
                            bmMajorholder6 += HUcoursebreakdownBM[i];
                            bmMajorholder6 += "\n";
                        }
                        majorBreakdown2.setText(bmMajorholder6);
                        break;
                    default:
                        break;
                }
                switch (minor) {
                    case "Mathematics":
                        String mathMinorHolder6 = "";
                        for (int i = 0; i < huMathMinor.length; i++) {
                            mathMinorHolder6 += huMathMinor[i];
                            mathMinorHolder6 += "\n";
                        }
                        minorBreakdown2.setText(mathMinorHolder6);
                        return;
                    case "Psychology":
                        String PsychMinorHolder6 = "";
                        for (int i = 0; i < huPsychMinor.length; i++) {
                            PsychMinorHolder6 += huPsychMinor[i];
                            PsychMinorHolder6 += "\n";
                        }
                        minorBreakdown2.setText(PsychMinorHolder6);
                        return;
                    default:
                        return;
                }
            default:
                break;
        }
    }
}