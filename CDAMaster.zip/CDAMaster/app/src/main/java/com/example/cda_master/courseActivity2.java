package com.example.cda_master;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

public class courseActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coursebreakdown2);
        //Create and set a listener on the layout view to handle the swiping
        View view = findViewById(R.id.courselayout2);
        view.setOnTouchListener(new DetectSwiping(courseActivity2.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent = new Intent(courseActivity2.this, courseActivity3.class);
                startActivity(topIntent);
            }
            public void onSwipeRight(){
                Intent intent = new Intent(courseActivity2.this, costActivity2.class);
                startActivity(intent);

            }
            public void onSwipeLeft(){
                //Do Nothing
            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent = new Intent(courseActivity2.this, courseActivity.class);
                startActivity(downIntent);
            }
        });
    }
}