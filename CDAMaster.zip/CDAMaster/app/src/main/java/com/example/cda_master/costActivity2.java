package com.example.cda_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

public class costActivity2 extends AppCompatActivity {
    float x1, x2, y1, y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.costbreakdown2);
        View view = findViewById(R.id.costlayout2);
        view.setOnTouchListener(new DetectSwiping(costActivity2.this){
            public void onSwipeTop(){
                //Swap to new cost activity
                Intent topIntent2 = new Intent(costActivity2.this, costActivity3.class);
                startActivity(topIntent2);
            }
            public void onSwipeRight(){

            }
            public void onSwipeLeft(){
                //Swap to course breakdown
                Intent intent = new Intent(costActivity2.this, courseActivity2.class);
                startActivity(intent);
            }
            public void onSwipeBottom(){
                //Swap to new cost activity
                Intent downIntent2 = new Intent(costActivity2.this, costActivity.class);
                startActivity(downIntent2);
            }
        });
    }

    public void openCourseActivity(){
        Intent intent = new Intent(this, courseActivity.class);
        startActivity(intent);
    }
}