package com.example.cda_master;

import java.util.Random;
import java.util.Timer;

public class Perceptron {

    class Trainer{
        double[] inputs;
        int answer;

        Trainer(double x, double y, int a){
            inputs = new double[]{x,y,1};
            answer=a;
        }
    }

    Trainer[] training = new Trainer[2000];
    double[] weights;
    double c = 0.00001;
    int count;
    String[] myprefix = new String[10];
    String[] mysuffix = new String[50];


    /*
    public Perceptron(int n){
        Random r = new Random();
        weights = new double[n];
        String url = "";
        myprefix = new String[]{"", "admission.", "admissions.", "financialaid.", "finaid.", "sfa.", "uaa.", "depts."
        , "sfs.", "admission.enrollment.", "studentcentral."};

        //31 total so far
        mysuffix = new String[]{"/finaid/", "/cost.php", "/costs/", "/cost", "/paying/", "/cost/", "/table-group-2.php", "/table-group-1.php"
        , "/costsandfinancialaid/", "/costsandfinaid/", "/tuitionfees.php", "/tuitionfees/", "/cost-of-attendance/", "/costattendance/"
        , "/resources/", "/resources-policies/", "/cost-attendance/", "/invest/", "/tuition/", "/prospect/" , "/budget/", "/budget.htm",
        "/about-harvard/", "/harvard-glance/", "/tuition-aid/", "/index.html", "/pay-for-college/" , "/cost-of-iu/", "/estimated-cost.html"
        , "/estimated-cost/", "/estimatedcost/"};



        for(int i =0; i<weights.length; i++){
            weights[i] = r.nextDouble()*2-1;
        }

        for(int i =0; i<training.length; i++){
            double x = r.nextDouble() *weights[i];
            double y = r.nextDouble() * weights[i];
            int answer;
            if(y<f(x)){
                answer = -1;
            }
            else{
                answer = 1;
            }
            training[i] = new Trainer(x,y, answer);
        }

        new Timer(10,(ActionEvent e) ->{
           findURL(url); //Placeholder
        }).start();
    } */

    //Weight
    private double f(double x){
        return x*.7+40;
    }

    //Weight
    int feedForward(double[] inputs){
        assert inputs.length == weights.length;
        double sum = 0;
        for(int i =0; i<weights.length;i++){
            sum += inputs[i] * weights[i];
        }
        return activate(sum);
    }

    //Bias
    int activate(double s){
        if(s > 0){
            return 1;
        }
        else{
            return -1;
        }
    }

    void train(double[] inputs, int desired){
        int guess = feedForward(inputs);
        double error = desired - guess;
        for(int i =0; i<weights.length; i++){
            weights[i] += c*error*inputs[i];
        }
    }

    public void findURL(String url){
        train(training[count].inputs, training[count].answer);
        count = (count+1)%training.length;

        for(int i =0; i<count; i++){
            int guess = feedForward(training[i].inputs);
            int x = (int) training[i].inputs[0] - 4;
            int y = (int) training[i].inputs[1]-4;

            if(guess > 0){
                //Do something
                //Maybe call the volley request in try catch block to see if URL is functional. If false restart perceptron else parse

            }
            else{
                //Do another thing
                //The perceptron failed to find a viable url so it tries again with different weights?
            }

        }
    }

}
